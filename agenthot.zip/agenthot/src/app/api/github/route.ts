import { NextRequest, NextResponse } from 'next/server';
import { BlogProject } from '@/data/types';

// Cache for 30 minutes
let cachedProjects: BlogProject[] | null = null;
let cacheTimestamp: number = 0;
const CACHE_DURATION = 30 * 60 * 1000;

const GITHUB_API = 'https://api.github.com';

/**
 * Fixed list of curated Agent / MCP repos.
 * We fetch live data (stars, updatedAt, description) from GitHub /repos/{owner}/{repo},
 * but keep our own category, readme, installCmd, and quickStart overrides.
 */
const CURATED_REPOS: Array<{
  fullName: string;
  id: string;
  category: BlogProject['category'];
  readmeOverride?: string;
  installCmdOverride?: string;
  quickStartOverride?: string;
}> = [
  {
    fullName: 'Significant-Gravitas/AutoGPT',
    id: 'b1',
    category: 'framework',
    readmeOverride:
      'AutoGPT 是最早的自主 AI Agent 项目之一。它让 GPT-4 能够自主思考、规划和执行任务，无需人类逐步指导。核心架构包括：目标管理、记忆系统、工具调用和自主决策循环。',
    installCmdOverride:
      'git clone https://github.com/Significant-Gravitas/AutoGPT.git && cd AutoGPT && pip install -r requirements.txt',
    quickStartOverride:
      '1. 设置 OpenAI API Key\n2. 运行 ./run agent start\n3. 输入你的目标，Agent 将自主规划和执行',
  },
  {
    fullName: 'langchain-ai/langchain',
    id: 'b2',
    category: 'framework',
    readmeOverride:
      'LangChain 是构建 LLM 应用的最流行框架。核心组件包括：Chains（链式调用）、Agents（智能代理）、Memory（记忆管理）、Tools（工具集成）。配合 LangGraph 可构建复杂的有状态 Agent 工作流。',
    installCmdOverride: 'pip install langchain langchain-core langchain-community',
    quickStartOverride:
      'from langchain.agents import AgentExecutor\nfrom langchain_openai import ChatOpenAI\n\nagent = AgentExecutor.from_agent_and_tools(...)\nagent.invoke({"input": "你的问题"})',
  },
  {
    fullName: 'crewAIInc/crewAI',
    id: 'b3',
    category: 'framework',
    readmeOverride:
      'CrewAI 是多 Agent 协作框架。通过定义角色（Role）、目标（Goal）和工具（Tool），让多个 Agent 组成"团队"协作完成复杂任务。支持顺序、层级和自定义编排模式。',
    installCmdOverride: 'pip install crewai',
    quickStartOverride:
      'from crewai import Agent, Task, Crew\n\nresearcher = Agent(role="研究员", goal="收集信息", tools=[search_tool])\nwriter = Agent(role="写作者", goal="撰写报告")\ncrew = Crew(agents=[researcher, writer], tasks=[...])\nresult = crew.kickoff()',
  },
  {
    fullName: 'OpenInterpreter/open-interpreter',
    id: 'b4',
    category: 'coding',
    readmeOverride:
      'Open Interpreter 让 LLM 在你的电脑上运行代码（Python、JS、Shell 等），完成文件操作、数据处理、网页浏览等任务。是代码 Agent 的核心基础设施之一。',
    installCmdOverride: 'pip install open-interpreter',
    quickStartOverride:
      'interpreter\n# 然后用自然语言输入任务，如"帮我分析这个CSV文件的统计数据"',
  },
  {
    fullName: 'openai/swarm',
    id: 'b5',
    category: 'framework',
    readmeOverride:
      'Swarm 是 OpenAI 推出的多 Agent 编排教育框架。轻量级设计，核心概念是 Routine（例程）和 Handoff（交接）。适合学习多 Agent 协作的基本模式。',
    installCmdOverride: 'pip install git+https://github.com/openai/swarm.git',
    quickStartOverride:
      'from swarm import Swarm, Agent\n\nclient = Swarm()\nagent_a = Agent(name="Agent A", instructions="...")\nresponse = client.run(agent_a, messages=[...])',
  },
  {
    fullName: 'langgenius/dify',
    id: 'b6',
    category: 'framework',
    readmeOverride:
      'Dify 是目前最成熟的开源 LLM 应用开发平台。提供可视化 Agent 工作流编排、RAG 知识库、企业级部署和多租户管理。MIT 开源，支持 MCP 协议。',
    installCmdOverride:
      'git clone https://github.com/langgenius/dify.git && cd dify/docker && docker compose up -d',
    quickStartOverride:
      '1. 访问 http://localhost/install 完成初始化\n2. 创建应用 → 选择 Agent 类型\n3. 配置工具和工作流\n4. 发布并测试',
  },
  {
    fullName: 'geekan/MetaGPT',
    id: 'b7',
    category: 'coding',
    readmeOverride:
      'MetaGPT 是多 Agent 软件开发框架。给定一行需求，自动输出 PRD、系统设计、任务列表、代码仓库。模拟软件公司的角色分工（产品经理、架构师、工程师等）。',
    installCmdOverride: 'pip install metagpt',
    quickStartOverride:
      'from metagpt.software_company import generate_repo\nawait generate_repo("创建一个待办事项应用")',
  },
  {
    fullName: 'modelcontextprotocol/servers',
    id: 'b8',
    category: 'mcp',
    readmeOverride:
      'MCP (Model Context Protocol) 官方参考实现集合。包含文件系统、数据库、GitHub、Slack、搜索引擎等常用 MCP Server。是 Agent 工具集成的标准协议。',
    installCmdOverride: 'npm install @modelcontextprotocol/server-filesystem',
    quickStartOverride: 'npx @modelcontextprotocol/server-filesystem /path/to/allowed/dir',
  },
  {
    fullName: 'browser-use/browser-use',
    id: 'b9',
    category: 'tool',
    readmeOverride:
      'Browser Use 让 AI Agent 能够控制浏览器。支持自然语言指令操作网页，包括点击、输入、滚动、截图等。是 Web Agent 的核心工具。',
    installCmdOverride: 'pip install browser-use',
    quickStartOverride:
      'from browser_use import Agent\nagent = Agent(task="在 Google 上搜索 AI Agent 最新动态")\nawait agent.run()',
  },
  {
    fullName: 'pydantic/pydantic-ai',
    id: 'b10',
    category: 'framework',
    readmeOverride:
      'Pydantic AI 是类型安全的 Agent 开发框架。利用 Pydantic 的数据验证能力，确保 Agent 输入输出的类型安全，减少运行时错误。支持依赖注入和结构化输出。',
    installCmdOverride: 'pip install pydantic-ai',
    quickStartOverride:
      'from pydantic_ai import Agent\n\nagent = Agent("openai:gpt-4o", result_type=list[str])\nresult = await agent.run("列出5个AI Agent框架")',
  },
  {
    fullName: 'reworkd/AgentGPT',
    id: 'b11',
    category: 'framework',
    readmeOverride:
      'AgentGPT 是浏览器内的自主 AI Agent 平台。无需编程，在浏览器中即可配置和部署自主 Agent。支持目标设定、自主规划和工具调用。',
    installCmdOverride:
      'git clone https://github.com/reworkd/AgentGPT.git && cd AgentGPT && npm install && npm run dev',
    quickStartOverride:
      '1. 访问 http://localhost:3000\n2. 输入 Agent 名称和目标\n3. Agent 将自主规划并执行任务',
  },
  {
    fullName: 'livekit/agents',
    id: 'b12',
    category: 'voice',
    readmeOverride:
      'LiveKit Agents 是实时多模态 Agent 框架，专注于语音和视频 Agent。基于 WebRTC 实现低延迟的实时交互，适合构建语音助手、视频客服等实时 Agent 应用。',
    installCmdOverride: 'pip install livekit-agents livekit-plugins-openai',
    quickStartOverride:
      'from livekit.agents import Agent, Worker\n\nagent = Agent(instructions="你是语音助手")\nWorker(entrypoint=agent).run()',
  },
  {
    fullName: 'stackblitz/bolt.new',
    id: 'b13',
    category: 'coding',
    readmeOverride:
      'Bolt.new 是浏览器内的全栈 Web Agent IDE。用自然语言描述需求，Agent 自动生成代码、运行预览、部署上线。支持 React、Next.js、Vue 等主流框架。',
    installCmdOverride: 'git clone https://github.com/stackblitz/bolt.new.git && npm install',
    quickStartOverride:
      '1. 打开 bolt.new\n2. 描述你想要的应用\n3. Agent 自动生成、预览、部署',
  },
  {
    fullName: 'punkpeye/awesome-mcp-servers',
    id: 'b14',
    category: 'mcp',
    readmeOverride:
      '最全面的 MCP Server 目录。收录了 500+ 个开源 MCP Server，覆盖数据库、搜索引擎、文件系统、开发工具、生产力工具等所有 Agent 工具需求。',
    installCmdOverride: '无需安装，查阅目录找到需要的 MCP Server',
    quickStartOverride:
      '1. 浏览 awesome-mcp-servers 列表\n2. 找到需要的工具类型\n3. 按照对应 Server 的安装说明操作',
  },
];

interface GitHubRepoResponse {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  stargazers_count: number;
  language: string | null;
  updated_at: string;
  html_url: string;
  topics: string[];
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get('category') || 'all';
  const sort = searchParams.get('sort') || 'stars';
  const search = searchParams.get('q') || '';
  const limit = parseInt(searchParams.get('limit') || '30');
  const forceRefresh = searchParams.get('refresh') === 'true';

  // Return cached data if fresh
  if (!forceRefresh && cachedProjects && Date.now() - cacheTimestamp < CACHE_DURATION) {
    return NextResponse.json({
      projects: filterAndSort(cachedProjects, category, sort, search, limit),
      total: cachedProjects.length,
      cached: true,
    });
  }

  // Fetch live data for each curated repo
  const settled = await Promise.allSettled(
    CURATED_REPOS.map(async (entry) => {
      const res = await fetch(`${GITHUB_API}/repos/${entry.fullName}`, {
        headers: {
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'AgentHot/1.0',
        },
        signal: AbortSignal.timeout(10_000),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status} for ${entry.fullName}`);
      const repo: GitHubRepoResponse = await res.json();

      const project: BlogProject = {
        id: entry.id,
        name: repo.name,
        fullName: repo.full_name,
        description: repo.description?.substring(0, 300) ?? '',
        stars: repo.stargazers_count,
        language: repo.language ?? 'Unknown',
        updatedAt: repo.updated_at,
        url: repo.html_url,
        category: entry.category,
        topics: (repo.topics ?? []).slice(0, 8),
        readme: entry.readmeOverride ?? repo.description ?? '暂无 README 描述',
        installCmd:
          entry.installCmdOverride ?? `git clone ${repo.html_url}.git && cd ${repo.name}`,
        quickStart:
          entry.quickStartOverride ?? `请访问 ${repo.html_url} 查看快速开始指南`,
      };
      return project;
    })
  );

  const projects: BlogProject[] = [];
  settled.forEach((result, i) => {
    if (result.status === 'fulfilled') {
      projects.push(result.value);
    } else {
      // On failure (rate limit or network error), use static fallback for this specific repo
      console.warn(`[github] Failed to fetch ${CURATED_REPOS[i].fullName}:`, result.reason);
      const entry = CURATED_REPOS[i];
      const [, repoName] = entry.fullName.split('/');
      // Use static star counts as reasonable fallback
      const STATIC_STARS: Record<string, number> = {
        'b1': 172000,  // AutoGPT
        'b2': 98500,   // LangChain
        'b3': 28000,   // CrewAI
        'b4': 57000,   // Open Interpreter
        'b5': 15000,   // Swarm
        'b6': 92000,   // Dify
        'b7': 46000,   // MetaGPT
        'b8': 32000,   // MCP Servers
        'b9': 25000,   // Browser Use
        'b10': 12000,  // Pydantic AI
        'b11': 33000,  // AgentGPT
        'b12': 8900,   // LiveKit Agents
        'b13': 21000,  // Bolt.new
        'b14': 18000,  // Awesome MCP Servers
      };
      projects.push({
        id: entry.id,
        name: repoName,
        fullName: entry.fullName,
        description: entry.readmeOverride ?? '',
        stars: STATIC_STARS[entry.id] ?? 0,
        language: 'Unknown',
        updatedAt: new Date().toISOString(),
        url: `https://github.com/${entry.fullName}`,
        category: entry.category,
        topics: [],
        readme: entry.readmeOverride ?? '',
        installCmd: entry.installCmdOverride ?? `git clone https://github.com/${entry.fullName}.git`,
        quickStart: entry.quickStartOverride ?? '',
      });
    }
  });

  // Check if any succeeded (if all failed, mark as fallback)
  const successCount = settled.filter((r) => r.status === 'fulfilled').length;
  const isFallback = successCount === 0;

  cachedProjects = projects;
  cacheTimestamp = Date.now();

  return NextResponse.json({
    projects: filterAndSort(projects, category, sort, search, limit),
    total: projects.length,
    cached: false,
    fallback: isFallback,
    liveCount: successCount,
  });
}

function filterAndSort(
  projects: BlogProject[],
  category: string,
  sort: string,
  search: string,
  limit: number
): BlogProject[] {
  let filtered = projects;

  if (category !== 'all') {
    filtered = filtered.filter((p) => p.category === category);
  }

  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.topics.some((t) => t.toLowerCase().includes(q))
    );
  }

  const sorted = [...filtered].sort((a, b) => {
    if (sort === 'stars') return b.stars - a.stars;
    if (sort === 'updated')
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    return a.name.localeCompare(b.name);
  });

  return sorted.slice(0, limit);
}
