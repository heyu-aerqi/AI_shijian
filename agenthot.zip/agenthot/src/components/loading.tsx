"use client";

import { Loader2, RefreshCw } from "lucide-react";

interface LoadingSpinnerProps {
  message?: string;
  size?: "sm" | "md" | "lg";
}

export function LoadingSpinner({ message = "加载中...", size = "md" }: LoadingSpinnerProps) {
  const sizeMap = {
    sm: "h-4 w-4",
    md: "h-6 w-6",
    lg: "h-8 w-8",
  };

  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3">
      <Loader2 className={`${sizeMap[size]} animate-spin text-blue-500`} />
      <p className="text-sm text-muted-foreground">{message}</p>
    </div>
  );
}

interface DataStatusProps {
  cached: boolean;
  lastUpdated: string;
  onRefresh: () => void;
  isLoading?: boolean;
}

export function DataStatus({ cached, lastUpdated, onRefresh, isLoading }: DataStatusProps) {
  return (
    <div className="flex items-center gap-2 text-xs text-muted-foreground">
      <span className="inline-flex items-center gap-1">
        <span className={`h-1.5 w-1.5 rounded-full ${cached ? "bg-green-500" : "bg-blue-500"}`} />
        {cached ? "缓存数据" : "实时数据"}
      </span>
      {lastUpdated && (
        <span>
          更新于 {new Date(lastUpdated).toLocaleTimeString("zh-CN")}
        </span>
      )}
      <button
        onClick={onRefresh}
        disabled={isLoading}
        className="inline-flex items-center gap-1 hover:text-foreground transition-colors disabled:opacity-50"
      >
        <RefreshCw className={`h-3 w-3 ${isLoading ? "animate-spin" : ""}`} />
        刷新
      </button>
    </div>
  );
}
