import { notFound } from "next/navigation";
import Parser from "rss-parser";
import { ArrowLeft, ExternalLink, Share2, Bookmark, Flame, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { HotScore, TypeBadge } from "@/components/badges";
import { fetchAnthropicNews } from "@/lib/fetchers/anthropic";
import { fetchHackerNews } from "@/lib/fetchers/hackernews";
import { fetchAihot } from "@/lib/fetchers/aihot";
import { fetchMcpAibase } from "@/lib/fetchers/mcpaibase";
import { SOURCES, calculateHotScore, isAgentRelated, autoClassify } from "@/data/rss-sources";
import { formatDistanceToNow, formatDate } from "@/lib/date";
import type { FeedItem } from "@/data/types";
import Link from "next/link";

// Allow all dynamic ids (RSS items are generated at runtime, not statically known).
export const dynamicParams = true;
export const dynamic = "force-dynamic";

const parser = new Parser({
  timeout: 12_000,
  headers: {
    "User-Agent":
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    Accept: "application/rss+xml, application/xml, text/xml, application/atom+xml",
  },
});

function stripHtml(html: string): string {
  return html
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function hashString(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h * 31 + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h).toString(36);
}

async function fetchAllItems(): Promise<FeedItem[]> {
  const now = new Date();
  const settled = await Promise.allSettled(
    SOURCES.map(async (source) => {
      if (source.fetcher === "html") {
        if (source.id === "mcpaibase") return await fetchMcpAibase(source);
        return await fetchAnthropicNews(source);
      }
      if (source.fetcher === "api") {
        if (source.id === "aihot") return await fetchAihot(source);
        return await fetchHackerNews(source);
      }
      // rss
      try {
        const feed = await parser.parseURL(source.url);
        const items = feed.items || [];
        return items
          .filter((it) => it.title)
          .slice()
          .sort((a, b) => {
            const ta = new Date(a.isoDate || a.pubDate || 0).getTime();
            const tb = new Date(b.isoDate || b.pubDate || 0).getTime();
            return tb - ta;
          })
          .slice(0, 30)
          .map((item, idx) => {
            const title = item.title || "";
            const rawSummary = item.contentSnippet || item.content || "";
            const summary = stripHtml(rawSummary).slice(0, 500);
            const pubDate =
              item.isoDate || item.pubDate || new Date().toISOString();
            const { isRelated, matchCount } = isAgentRelated(
              title,
              summary,
              source.agentKeywords
            );
            const itemType = autoClassify(title, summary, source.category);
            const hotScore = calculateHotScore({
              sourceWeight: source.weight,
              publishedDate: new Date(pubDate),
              now,
              hasAgentKeywords: isRelated,
              keywordMatchCount: matchCount,
            });
            const url = item.link || undefined;
            const id = `${source.id}-${hashString(url || title)}-${idx}`;
            const content = stripHtml(item.content || summary).slice(0, 5000);
            const tags = extractTags(title, summary, source.agentKeywords);
            return {
              id,
              type: itemType,
              title,
              summary,
              source: source.name,
              hotScore,
              publishTime: pubDate,
              tags,
              url,
              recommendation: isRelated
                ? `本文来自 ${source.name}，与 Agent 领域相关（匹配关键词：${matchedKeywordList(tags, source.agentKeywords)}）。热度评分 ${hotScore}/100。`
                : `本文来自 ${source.name}，属于 ${itemType} 类动态。`,
              aiSummary: summary || "暂无 AI 摘要，请阅读原文获取完整信息。",
              content: content || summary || "暂无正文内容，请访问原文链接阅读完整文章。",
            } as FeedItem;
          });
      } catch (err) {
        console.warn(`[rss:${source.id}]`, err);
        return [];
      }
    })
  );

  const allItems: FeedItem[] = [];
  for (const r of settled) {
    if (r.status === "fulfilled") allItems.push(...r.value);
  }

  // dedupe
  const seen = new Map<string, FeedItem>();
  for (const item of allItems) {
    const key = item.url || item.id;
    const ex = seen.get(key);
    if (!ex || item.hotScore > ex.hotScore) seen.set(key, item);
  }

  return Array.from(seen.values()).sort((a, b) => {
    if (b.hotScore !== a.hotScore) return b.hotScore - a.hotScore;
    return new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime();
  });
}

function extractTags(title: string, summary: string, keywords: string[]): string[] {
  const text = `${title} ${summary}`.toLowerCase();
  const matched = keywords.filter((kw) => text.includes(kw.toLowerCase()));
  return [...new Set(matched)].slice(0, 5);
}

function matchedKeywordList(tags: string[], keywords: string[]): string {
  const matched = tags.filter((t) =>
    keywords.some((k) => k.toLowerCase() === t.toLowerCase())
  );
  return matched.length > 0 ? matched.join("、") : "通用";
}

export default async function ItemDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const allItems = await fetchAllItems();
  const item = allItems.find((i) => i.id === id);

  if (!item) {
    notFound();
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top bar */}
      <div className="flex items-center justify-between mb-6">
        <Link href="/">
          <Button variant="ghost" size="sm" className="gap-1.5">
            <ArrowLeft className="h-4 w-4" />
            返回列表
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          {item.url && (
            <a href={item.url} target="_blank" rel="noopener noreferrer">
              <Button variant="ghost" size="sm" className="gap-1.5">
                <ExternalLink className="h-4 w-4" />
                原文
              </Button>
            </a>
          )}
          <Button variant="ghost" size="sm" className="gap-1.5">
            <Share2 className="h-4 w-4" />
            分享
          </Button>
          <Button variant="ghost" size="sm" className="gap-1.5">
            <Bookmark className="h-4 w-4" />
            收藏
          </Button>
        </div>
      </div>

      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-3">
          <TypeBadge type={item.type} />
          <Badge
            variant="outline"
            className="text-xs bg-orange-500/10 text-orange-400 border-orange-500/20"
          >
            <Flame className="h-3 w-3 mr-1" />
            {item.hotScore}
          </Badge>
          <span className="text-xs text-muted-foreground">·</span>
          <span className="text-sm text-muted-foreground font-medium">
            {item.source}
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-bold leading-tight mb-3">
          {item.title}
        </h1>

        <div className="flex items-center gap-3 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" />
            {formatDate(item.publishTime)}
          </span>
          <span>·</span>
          <span>{formatDistanceToNow(item.publishTime)}</span>
        </div>
      </div>

      <Separator className="my-6" />

      {/* Tags */}
      <div className="flex items-center gap-2 flex-wrap mb-6">
        {item.tags.map((tag) => (
          <Badge key={tag} variant="secondary" className="text-xs">
            {tag}
          </Badge>
        ))}
      </div>

      {/* Recommendation */}
      <div className="p-4 rounded-xl bg-blue-500/5 border border-blue-500/10 mb-6">
        <h3 className="text-sm font-bold text-blue-500 mb-2">推荐理由</h3>
        <p className="text-sm leading-relaxed">{item.recommendation}</p>
      </div>

      {/* AI Summary */}
      <div className="p-4 rounded-xl bg-purple-500/5 border border-purple-500/10 mb-6">
        <h3 className="text-sm font-bold text-purple-500 mb-2">AI 摘要</h3>
        <p className="text-sm leading-relaxed">{item.aiSummary}</p>
      </div>

      <Separator className="my-6" />

      {/* Full Content */}
      <article className="prose prose-sm dark:prose-invert max-w-none">
        {item.content.split("\n").map((line, i) => {
          if (line.startsWith("# ")) {
            return (
              <h2 key={i} className="text-xl font-bold mt-6 mb-3">
                {line.slice(2)}
              </h2>
            );
          }
          if (line.startsWith("## ")) {
            return (
              <h3 key={i} className="text-lg font-bold mt-5 mb-2">
                {line.slice(3)}
              </h3>
            );
          }
          if (line.startsWith("- ")) {
            return (
              <li key={i} className="text-sm leading-relaxed ml-4">
                {line.slice(2)}
              </li>
            );
          }
          if (/^\d+\.\s/.test(line)) {
            return (
              <li key={i} className="text-sm leading-relaxed ml-4 list-decimal">
                {line.replace(/^\d+\.\s/, "")}
              </li>
            );
          }
          if (line.trim() === "") {
            return <br key={i} />;
          }
          if (line.startsWith("```")) {
            return null;
          }
          return (
            <p key={i} className="text-sm leading-relaxed mb-2">
              {line}
            </p>
          );
        })}
      </article>

      <Separator className="my-8" />

      {/* Footer */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">
          来源：{item.source}
        </span>
        {item.url && (
          <a href={item.url} target="_blank" rel="noopener noreferrer">
            <Button variant="outline" size="sm" className="gap-1.5">
              <ExternalLink className="h-4 w-4" />
              阅读原文
            </Button>
          </a>
        )}
      </div>
    </div>
  );
}