"use client";

import { useState } from "react";
import { useFeedItems } from "@/lib/hooks";
import { feedItems } from "@/data/feed-data";
import { FeedCard, DateDivider } from "@/components/feed-card";
import { LoadingSpinner, DataStatus } from "@/components/loading";
import { formatDate } from "@/lib/date";
import { Badge } from "@/components/ui/badge";
import { FeedItem } from "@/data/types";
import { Building2, Search } from "lucide-react";

const industryFilters = [
  { value: "all", label: "全部" },
  { value: "融资", label: "融资动态" },
  { value: "监管", label: "政策法规" },
  { value: "市场", label: "市场报告" },
  { value: "企业", label: "企业动态" },
];

export default function IndustryPage() {
  const [filter, setFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { items, cached, lastUpdated, isLoading, mutate } = useFeedItems({
    type: "industry",
    search: searchQuery,
    limit: 50,
  });

  const displayItems: FeedItem[] = items.length > 0
    ? items.filter((item) => {
        if (filter === "all") return true;
        return (
          item.tags.some((t) => t.includes(filter)) ||
          item.title.includes(filter) ||
          item.summary.includes(filter)
        );
      })
    : feedItems.filter((item) => {
        if (item.type !== "industry") return false;
        if (filter !== "all") {
          return (
            item.tags.some((t) => t.includes(filter)) ||
            item.title.includes(filter) ||
            item.summary.includes(filter)
          );
        }
        return true;
      });

  const groupedItems = (() => {
    const groups: Record<string, FeedItem[]> = {};
    displayItems
      .sort(
        (a, b) =>
          new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime()
      )
      .forEach((item) => {
        const date = formatDate(item.publishTime);
        if (!groups[date]) groups[date] = [];
        groups[date].push(item);
      });
    return groups;
  })();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Building2 className="h-5 w-5 text-green-500" />
          <h1 className="text-xl font-bold">行业动态</h1>
          <Badge variant="secondary" className="text-xs">{displayItems.length} 条</Badge>
        </div>
        {items.length > 0 && (
          <DataStatus cached={cached} lastUpdated={lastUpdated} onRefresh={() => mutate()} isLoading={isLoading} />
        )}
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="搜索行业动态..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-9 pl-9 pr-3 text-sm rounded-lg border border-border/50 bg-muted/50 placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-green-500/30"
          />
        </div>
        <div className="flex items-center gap-1 flex-wrap">
          {industryFilters.map((f) => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                filter === f.value
                  ? "bg-green-500/10 text-green-500 border border-green-500/20"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {isLoading && items.length === 0 && <LoadingSpinner message="正在加载行业动态..." />}

      {!isLoading && (
        <div className="space-y-2">
          {Object.entries(groupedItems).map(([date, dateItems]) => (
            <div key={date}>
              <DateDivider date={date} />
              <div className="space-y-2">
                {dateItems.map((item) => (
                  <FeedCard key={item.id} item={item} />
                ))}
              </div>
            </div>
          ))}
          {displayItems.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-sm">暂无相关行业动态</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
