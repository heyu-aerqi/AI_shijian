export type FetcherType = 'rss' | 'html' | 'api';

export interface SourceConfig {
  id: string;
  name: string;
  url: string;
  /**
   * Which tab this source primarily belongs to.
   * 'industry' means it appears in 全部 tab and 行业 tab.
   */
  category: 'model' | 'industry' | 'tips';
  logo: string;
  fetcher: FetcherType;
  agentKeywords: string[];
  weight: number;
  isChinese: boolean;
}

/**
 * Tier 1 sources — verified working (HTTP 200 + real RSS/HTML/API content)
 *
 * 11 RSS + 1 HTML + 1 API = 13 data sources.
 *
 * Tab mapping (per user decision):
 *   全部 = all
 *   模型 = model-category sources
 *   技巧 = tips-category sources
 *   行业 = industry-category sources
 */
export const SOURCES: SourceConfig[] = [
  // ========== 模型/产品类 (5 sources) ==========
  {
    id: 'openai',
    name: 'OpenAI',
    url: 'https://openai.com/news/rss.xml',
    category: 'model',
    logo: '🟢',
    fetcher: 'rss',
    agentKeywords: ['agent', 'codex', 'gpt', 'o1', 'o3', 'o4', 'chatgpt', 'api', 'sora', 'agi'],
    weight: 10,
    isChinese: false,
  },
  {
    id: 'google-ai',
    name: 'Google AI',
    url: 'https://blog.google/technology/ai/rss/',
    category: 'model',
    logo: '🔵',
    fetcher: 'rss',
    agentKeywords: ['agent', 'gemini', 'gemma', 'model', 'ai', 'project-astra', 'deepmind'],
    weight: 10,
    isChinese: false,
  },
  {
    id: 'google-blog',
    name: 'Google Blog',
    url: 'https://blog.google/feed/',
    category: 'model',
    logo: '🔷',
    fetcher: 'rss',
    agentKeywords: ['agent', 'gemini', 'ai', 'model', 'gemma', 'bard', 'deepmind', 'astra'],
    weight: 8,
    isChinese: false,
  },
  {
    id: 'huggingface',
    name: 'Hugging Face',
    url: 'https://huggingface.co/blog/feed.xml',
    category: 'model',
    logo: '🤗',
    fetcher: 'rss',
    agentKeywords: ['agent', 'model', 'transformers', 'smolagents', 'inference', 'open-source', 'fine-tuning'],
    weight: 9,
    isChinese: false,
  },
  {
    id: 'anthropic',
    name: 'Anthropic',
    url: 'https://www.anthropic.com/news',
    category: 'model',
    logo: '🟤',
    fetcher: 'html',
    agentKeywords: ['claude', 'agent', 'computer-use', 'tool-use', 'mcp', 'model', 'opus', 'sonnet', 'haiku'],
    weight: 10,
    isChinese: false,
  },

  // ========== 行业类 (2 sources - 中文权威) ==========
  {
    id: 'qbitai',
    name: '量子位',
    url: 'https://www.qbitai.com/feed/',
    category: 'industry',
    logo: '⚛️',
    fetcher: 'rss',
    agentKeywords: ['Agent', '智能体', 'AI', '大模型', '具身智能', '融资', 'OpenAI', 'Claude', 'DeepSeek', 'Qwen'],
    weight: 9,
    isChinese: true,
  },
  {
    id: 'leiphone',
    name: '雷锋网',
    url: 'https://www.leiphone.com/feed',
    category: 'industry',
    logo: '🔶',
    fetcher: 'rss',
    agentKeywords: ['Agent', '智能体', 'AI', '大模型', 'Kimi', '智谱', '阿里', 'Claude', 'OpenAI'],
    weight: 8,
    isChinese: true,
  },

  // ========== 技巧类 (5 RSS + 1 API = 6 sources) ==========
  {
    id: 'langchain',
    name: 'LangChain',
    url: 'https://blog.langchain.dev/rss.xml',
    category: 'tips',
    logo: '🔗',
    fetcher: 'rss',
    agentKeywords: ['agent', 'langgraph', 'langchain', 'rag', 'tool', 'mcp', 'framework', 'orchestration'],
    weight: 10,
    isChinese: false,
  },
  {
    id: 'simon-willison',
    name: 'Simon Willison',
    url: 'https://simonwillison.net/atom/everything/',
    category: 'tips',
    logo: '🦆',
    fetcher: 'rss',
    agentKeywords: ['agent', 'claude', 'gpt', 'llm', 'cursor', 'claude-code', 'mcp', 'tool', 'rag'],
    weight: 10,
    isChinese: false,
  },
  {
    id: 'lilian-weng',
    name: "Lil'Log",
    url: 'https://lilianweng.github.io/index.xml',
    category: 'tips',
    logo: '🧠',
    fetcher: 'rss',
    agentKeywords: ['agent', 'llm', 'reasoning', 'rlhf', 'rag', 'tool', 'mcp', 'prompt', 'in-context'],
    weight: 9,
    isChinese: false,
  },
  {
    id: 'aws-ml',
    name: 'AWS ML',
    url: 'https://aws.amazon.com/blogs/machine-learning/feed/',
    category: 'tips',
    logo: '☁️',
    fetcher: 'rss',
    agentKeywords: ['agent', 'bedrock', 'sagemaker', 'claude', 'llm', 'rag', 'vector', 'foundation-model'],
    weight: 7,
    isChinese: false,
  },
  {
    id: 'cloudflare',
    name: 'Cloudflare',
    url: 'https://blog.cloudflare.com/rss/',
    category: 'tips',
    logo: '🛡️',
    fetcher: 'rss',
    agentKeywords: ['agent', 'workers-ai', 'llm', 'vectorize', 'ai-gateway', 'mcp', 'model'],
    weight: 7,
    isChinese: false,
  },
  {
    id: 'hackernews',
    name: 'Hacker News',
    url: 'https://hacker-news.firebaseio.com/v0/topstories.json',
    category: 'tips',
    logo: '🟧',
    fetcher: 'api',
    agentKeywords: [
      'ai', 'agent', 'claude', 'gpt', 'gpt-4', 'gpt-5', 'llm', 'llms',
      'mcp', 'cursor', 'copilot', 'deepseek', 'gemini', 'llama', 'qwen',
      'mistral', 'rag', 'openai', 'anthropic', 'chatgpt', 'llm-agent',
      'claude-code', 'codex', 'agentic', 'transformer', 'diffusion',
    ],
    weight: 8,
    isChinese: false,
  },

  // ========== MCP AIbase 目录 (1 source — MCP server directory) ==========
  {
    id: 'mcpaibase',
    name: 'MCP AIbase',
    // URL is the homepage we scrape; no public JSON API available
    url: 'https://mcp.aibase.com/zh',
    category: 'tips',
    logo: '🔌',
    fetcher: 'html',
    agentKeywords: [
      'mcp', 'model context protocol', 'tool', 'agent', 'server',
      'claude', 'cursor', 'llm', 'plugin', 'integration',
      'browser', 'database', 'search', 'code', 'image',
    ],
    weight: 8,
    isChinese: true,
  },

  // ========== AIHOT 精选聚合 (1 source — covers all categories) ==========
  {
    id: 'aihot',
    name: 'AIHOT 精选',
    // URL is unused (fetcher calls REST API directly), kept for display
    url: 'https://aihot.virxact.com/api/public/items',
    // category is 'industry' by default; actual per-item category is mapped in the fetcher
    category: 'industry',
    logo: '🔥',
    fetcher: 'api',
    agentKeywords: [
      'agent', '智能体', 'ai', '大模型', 'mcp', 'rag', 'llm',
      'claude', 'gpt', 'gemini', 'deepseek', 'kimi', 'qwen',
    ],
    weight: 9,
    isChinese: true,
  },
];

/**
 * Legacy alias kept for back-compat with imports elsewhere.
 */
export const RSS_SOURCES = SOURCES;

/**
 * Calculate hot score for a feed item based on source weight, recency, and relevance.
 */
export function calculateHotScore(params: {
  sourceWeight: number;
  publishedDate: Date;
  now: Date;
  hasAgentKeywords: boolean;
  keywordMatchCount: number;
}): number {
  const { sourceWeight, publishedDate, now, hasAgentKeywords, keywordMatchCount } = params;

  // Base score from source weight (0-10) -> scaled to 0-40
  let score = sourceWeight * 4;

  // Recency bonus: newer = higher score
  const hoursDiff = (now.getTime() - publishedDate.getTime()) / (1000 * 60 * 60);
  if (hoursDiff < 6) score += 25;
  else if (hoursDiff < 12) score += 20;
  else if (hoursDiff < 24) score += 15;
  else if (hoursDiff < 48) score += 10;
  else if (hoursDiff < 72) score += 5;

  // Agent relevance bonus
  if (hasAgentKeywords) score += 15;
  score += Math.min(keywordMatchCount * 3, 15);

  // Cap at 100
  return Math.min(Math.round(score), 100);
}

/**
 * Check if content is agent-related.
 */
export function isAgentRelated(title: string, summary: string, keywords: string[]): {
  isRelated: boolean;
  matchCount: number;
} {
  const text = `${title} ${summary}`.toLowerCase();
  let matchCount = 0;
  for (const kw of keywords) {
    if (text.includes(kw.toLowerCase())) matchCount++;
  }

  return {
    isRelated: matchCount > 0,
    matchCount,
  };
}

/**
 * Auto-classify feed item type based on content.
 * For Tier 1 sources we trust the source's default category more (boost +3)
 * to avoid mis-classifying e.g. quantum-bit articles as "tips".
 */
export function autoClassify(
  title: string,
  summary: string,
  sourceCategory: string
): 'model' | 'product' | 'industry' | 'tips' {
  const text = `${title} ${summary}`.toLowerCase();

  const modelKeywords = [
    'model', '模型', 'release', 'launch', 'benchmark', 'llm',
    'gpt', 'claude', 'gemini', 'qwen', 'deepseek', 'opus', 'sonnet',
  ];
  const productKeywords = [
    'product', '产品', 'feature', 'update', 'agent', 'copilot',
    'platform', 'tool', 'app', 'plugin', 'integration',
  ];
  const industryKeywords = [
    'funding', '融资', 'investment', 'policy', 'regulation',
    'market', 'report', 'revenue', 'ipo', 'valuation',
    '收购', 'acquisition', 'company', 'company news',
  ];
  const tipsKeywords = [
    'tutorial', '教程', 'how to', 'guide', 'best practice',
    'architecture', 'prompt', 'mcp', 'framework', 'how-to',
    'building', 'building with',
  ];

  const scores = {
    model: modelKeywords.filter((kw) => text.includes(kw)).length,
    product: productKeywords.filter((kw) => text.includes(kw)).length,
    industry: industryKeywords.filter((kw) => text.includes(kw)).length,
    tips: tipsKeywords.filter((kw) => text.includes(kw)).length,
  };

  // Strong boost to source's default category
  if (sourceCategory in scores) {
    scores[sourceCategory as keyof typeof scores] += 3;
  }

  const maxEntry = Object.entries(scores).reduce((a, b) => (b[1] > a[1] ? b : a));
  return maxEntry[0] as 'model' | 'product' | 'industry' | 'tips';
}