@echo off
chcp 65001 >nul
title AGENTHOT — Agent 行业动态聚合

echo ========================================
echo   AGENTHOT — Agent 行业动态聚合
echo ========================================
echo.

:: 检查 Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo ❌ 未检测到 Node.js，请先安装 Node.js (≥ 20.0.0)
  echo    下载地址: https://nodejs.org/
  echo.
  pause
  exit /b 1
)

for /f "tokens=*" %%i in ('node -v') do set NODE_VER=%%i
echo ✅ Node.js 版本: %NODE_VER%

where npm >nul 2>nul
if %errorlevel% neq 0 (
  echo ❌ 未检测到 npm，请确认 Node.js 安装是否完整
  pause
  exit /b 1
)

for /f "tokens=*" %%i in ('npm -v') do set NPM_VER=%%i
echo ✅ npm 版本: %NPM_VER%
echo.

:: 安装依赖
if not exist "node_modules" (
  echo 📦 首次运行，正在安装依赖（可能需要 1-3 分钟）...
  echo.
  call npm install
  if %errorlevel% neq 0 (
    echo.
    echo ❌ 依赖安装失败，请检查网络连接后重试
    pause
    exit /b 1
  )
  echo.
  echo ✅ 依赖安装完成！
  echo.
) else (
  echo ✅ 依赖已安装，跳过安装步骤
  echo.
)

:: 启动开发服务器
echo 🚀 启动开发服务器...
echo    浏览器访问: http://localhost:3000
echo    按 Ctrl+C 停止服务器
echo.

:: 延迟 3 秒后打开浏览器
start /b cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:3000"

call npm run dev
