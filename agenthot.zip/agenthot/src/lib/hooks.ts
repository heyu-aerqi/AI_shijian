"use client";

import useSWR from 'swr';
import { FeedItem, BlogProject, AgentProduct } from '@/data/types';
import { agentProducts } from '@/data/product-data';
import { blogProjects as fallbackBlogProjects } from '@/data/product-data';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

/**
 * Hook for fetching RSS feed items
 */
export function useFeedItems(options?: {
  type?: string;
  search?: string;
  limit?: number;
}) {
  const params = new URLSearchParams();
  if (options?.type && options.type !== 'all') params.set('type', options.type);
  if (options?.search) params.set('q', options.search);
  if (options?.limit) params.set('limit', String(options.limit));

  const query = params.toString();
  const url = `/api/feed${query ? `?${query}` : ''}`;

  const { data, error, isLoading, mutate } = useSWR<{
    items: FeedItem[];
    total: number;
    cached: boolean;
    lastUpdated: string;
  }>(url, fetcher, {
    refreshInterval: 5 * 60 * 1000, // Refresh every 5 minutes
    revalidateOnFocus: false,
    dedupingInterval: 60000, // Dedupe within 1 min
  });

  return {
    items: data?.items || [],
    total: data?.total || 0,
    cached: data?.cached || false,
    lastUpdated: data?.lastUpdated || '',
    isLoading,
    isError: !!error,
    mutate,
  };
}

/**
 * Hook for fetching GitHub projects
 */
export function useGitHubProjects(options?: {
  category?: string;
  sort?: string;
  search?: string;
  limit?: number;
}) {
  const params = new URLSearchParams();
  if (options?.category && options.category !== 'all')
    params.set('category', options.category);
  if (options?.sort) params.set('sort', options.sort);
  if (options?.search) params.set('q', options.search);
  if (options?.limit) params.set('limit', String(options.limit));

  const query = params.toString();
  const url = `/api/github${query ? `?${query}` : ''}`;

  const { data, error, isLoading, mutate } = useSWR<{
    projects: BlogProject[];
    total: number;
    cached: boolean;
    fallback?: boolean;
  }>(url, fetcher, {
    refreshInterval: 15 * 60 * 1000, // Refresh every 15 minutes
    revalidateOnFocus: false,
    dedupingInterval: 120000,
  });

  return {
    projects: data?.projects || [],
    total: data?.total || 0,
    cached: data?.cached || false,
    fallback: data?.fallback || false,
    isLoading,
    isError: !!error,
    mutate,
  };
}

/**
 * Hook for Agent products (currently local data, future: API)
 */
export function useAgentProducts(options?: {
  category?: string;
  region?: string;
  search?: string;
}) {
  // For now, products use local data as they need manual curation
  // Future: add an API route for product data
  const filtered = (() => {
    let products = agentProducts;

    if (options?.category && options.category !== 'all') {
      products = products.filter((p) => p.category === options.category);
    }

    if (options?.region && options.region !== 'all') {
      products = products.filter((p) =>
        options.region === 'domestic' ? p.isDomestic : !p.isDomestic
      );
    }

    if (options?.search) {
      const q = options.search.toLowerCase();
      products = products.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    return products.sort((a, b) => b.hotScore - a.hotScore);
  })();

  return {
    products: filtered,
    total: filtered.length,
    isLoading: false,
    isError: false,
  };
}
