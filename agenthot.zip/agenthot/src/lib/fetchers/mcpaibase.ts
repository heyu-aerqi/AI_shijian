/**
 * MCP AIbase (mcp.aibase.com/zh) fetcher
 *
 * The site is Nuxt SSR and has no public JSON API (the real API at
 * mcpapi.aibase.cn requires a login token).  Instead we scrape the
 * homepage HTML which contains all 60+ MCP server cards pre-rendered.
 *
 * Data we extract per card:
 *   id          — numeric string from href "/zh/server/{id}"
 *   name        — server name (text node before description)
 *   description — short Chinese/English blurb
 *   stars       — raw star count string (e.g. "190.2K")
 *   rating      — score string (e.g. "4.5")
 *   language    — programming language if shown (TypeScript | Python | …)
 *   certified   — whether "已认证" badge is present
 *
 * Maps to FeedItem type = 'tips' (MCP tools/guides/products are "技巧" content).
 */

import type { SourceConfig } from '@/data/rss-sources';
import type { FeedItem } from '@/data/types';

const MCP_HOME = 'https://mcp.aibase.com/zh';
const UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';

interface McpCard {
  id: string;
  name: string;
  description: string;
  starsRaw: string;
  stars: number; // numeric, 0 if unparseable
  rating: number; // 0-5
  language: string;
  certified: boolean;
  url: string;
}

/** Parse "190.2K" → 190200, "1.2M" → 1200000, plain integer ok too */
function parseStars(raw: string): number {
  const s = raw.trim().toUpperCase();
  const m = s.match(/^([\d.]+)([KM]?)$/);
  if (!m) return 0;
  const n = parseFloat(m[1]);
  if (m[2] === 'K') return Math.round(n * 1000);
  if (m[2] === 'M') return Math.round(n * 1_000_000);
  return Math.round(n);
}

/** Strip HTML tags and collapse whitespace */
function stripHtml(html: string): string {
  return html
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Extract MCP server cards from the raw homepage HTML.
 * Each card has an anchor href="/zh/server/{id}".
 */
function parseCards(html: string): McpCard[] {
  const seen = new Set<string>();
  const results: McpCard[] = [];

  // Match every anchor that links to a server detail page
  const cardRe = /href="\/zh\/server\/(\d+)"[^>]*>([\s\S]*?)<\/a>/g;
  let m: RegExpExecArray | null;

  while ((m = cardRe.exec(html)) !== null) {
    const id = m[1];
    if (seen.has(id)) continue;
    seen.add(id);

    const inner = m[2];
    const text = stripHtml(inner);

    // Certified badge
    const certified = inner.includes('已认证');

    // Programming language
    const langMatch = text.match(/\b(TypeScript|Python|JavaScript|Go|Rust|Java|C\+\+)\b/);
    const language = langMatch ? langMatch[1] : '';

    // Star count — formatted like "190.2K" or "64.0K"
    const starMatch = text.match(/([\d.]+[KMkm]?)\s*(?:stars?|⭐|\s)/i) ||
      text.match(/([\d.]+K)\s/);
    const starsRaw = starMatch ? starMatch[1] : '';
    const stars = parseStars(starsRaw);

    // Rating — "4.5分" or "5分"
    const ratingMatch = text.match(/([\d.]+)分/);
    const rating = ratingMatch ? parseFloat(ratingMatch[1]) : 0;

    // Name + description heuristic:
    //   1. Remove the programming-language / star / rating noise from the tail
    //   2. The first "word group" (often English) is the name
    //   3. The rest is the description
    let body = text
      .replace(/已认证/g, '')
      .replace(/\b(TypeScript|Python|JavaScript|Go|Rust|Java|C\+\+)\b/g, '')
      .replace(/([\d.]+[KMkm]?)\s*/gi, '')
      .replace(/([\d.]+)分/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    // Many names look like "Firecrawl MCP Server Firecrawl MCP Server是..." (repeated)
    // Deduplicate leading repetition
    const dedup = body.replace(/^(.{6,60})\s+\1\s*/, '$1 ');
    body = dedup;

    // Heuristic: name = everything before the first CJK character or "是/的/为/提供"
    const cjkIdx = body.search(/[\u4e00-\u9fff是的为提供（(：]/);
    let name = '';
    let description = '';
    if (cjkIdx > 0) {
      name = body.slice(0, cjkIdx).trim().replace(/\s+/g, ' ');
      description = body.slice(cjkIdx).trim();
    } else {
      // Fallback: split by first sentence separator
      const parts = body.split(/\.\s+|。/);
      name = parts[0].trim();
      description = parts.slice(1).join('. ').trim();
    }

    // Guard: name should not be empty
    if (!name) name = `MCP Server ${id.slice(-6)}`;

    results.push({
      id,
      name: name.slice(0, 80),
      description: description.slice(0, 300),
      starsRaw,
      stars,
      rating,
      language,
      certified,
      url: `https://mcp.aibase.com/zh/server/${id}`,
    });
  }

  return results;
}

/** Build hotScore from star count + rating */
function buildHotScore(card: McpCard): number {
  let score = 50; // base

  // Stars boost (log scale)
  if (card.stars >= 100_000) score += 25;
  else if (card.stars >= 50_000) score += 20;
  else if (card.stars >= 10_000) score += 15;
  else if (card.stars >= 1_000) score += 8;

  // Rating boost (0-5 → 0-15)
  score += Math.round((card.rating / 5) * 15);

  // Certified boost
  if (card.certified) score += 5;

  return Math.min(score, 100);
}

function buildTags(card: McpCard): string[] {
  const tags: string[] = ['mcp', 'tool'];
  if (card.language) tags.push(card.language.toLowerCase());
  if (card.certified) tags.push('certified');

  const text = `${card.name} ${card.description}`.toLowerCase();
  const keywords = [
    'agent', 'search', 'database', 'browser', 'image', 'video',
    'code', 'file', 'chat', 'knowledge', 'data', 'api',
    'claude', 'cursor', 'openai', 'llm',
  ];
  for (const kw of keywords) {
    if (text.includes(kw)) tags.push(kw);
  }
  return [...new Set(tags)].slice(0, 6);
}

export async function fetchMcpAibase(source: SourceConfig): Promise<FeedItem[]> {
  let html: string;
  try {
    const res = await fetch(MCP_HOME, {
      headers: {
        'User-Agent': UA,
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Cache-Control': 'no-cache',
      },
      signal: AbortSignal.timeout(20_000),
      next: { revalidate: 0 },
    });
    if (!res.ok) {
      console.warn(`[mcpaibase] HTTP ${res.status}`);
      return [];
    }
    html = await res.text();
  } catch (err) {
    console.warn('[mcpaibase] fetch error:', err);
    return [];
  }

  const cards = parseCards(html);
  if (cards.length === 0) {
    console.warn('[mcpaibase] parsed 0 cards — page structure may have changed');
    return [];
  }

  console.log(`[mcpaibase] parsed ${cards.length} MCP server cards`);

  const now = new Date().toISOString();
  const items: FeedItem[] = cards.map((card) => {
    const hotScore = buildHotScore(card);
    const tags = buildTags(card);

    const starsLabel = card.starsRaw ? ` · ⭐ ${card.starsRaw}` : '';
    const ratingLabel = card.rating > 0 ? ` · ${card.rating}分` : '';
    const certLabel = card.certified ? ' · 已认证' : '';
    const langLabel = card.language ? ` · ${card.language}` : '';

    const summary =
      card.description ||
      `${card.name} 是一个 MCP 服务器，可集成到 Claude、Cursor 等 AI 工具中。`;

    return {
      id: `mcpaibase-${card.id}`,
      type: 'tips' as const, // MCP server guides belong to "技巧" tab
      title: card.name,
      summary,
      source: `MCP AIbase${certLabel}${starsLabel}${ratingLabel}${langLabel}`,
      hotScore,
      publishTime: now,
      tags,
      url: card.url,
      recommendation: `本条目来自 MCP AIbase 目录，是一个${card.certified ? '经认证的' : ''}${card.language ? ' ' + card.language : ''} MCP 服务器。GitHub Stars: ${card.starsRaw || '未知'}，评分 ${card.rating || '未知'}/5。可接入 Claude Desktop、Cursor 等工具使用。`,
      aiSummary: summary,
      content: summary,
    };
  });

  return items;
}
