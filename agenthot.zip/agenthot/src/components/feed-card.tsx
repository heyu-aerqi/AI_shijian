"use client";

import Link from "next/link";
import { formatDistanceToNow } from "@/lib/date";
import { HotScore, TypeBadge } from "@/components/badges";
import { Card, CardContent } from "@/components/ui/card";
import { FeedItem } from "@/data/types";
import { cn } from "@/lib/utils";

interface FeedCardProps {
  item: FeedItem;
  compact?: boolean;
}

export function FeedCard({ item, compact }: FeedCardProps) {
  const timeAgo = formatDistanceToNow(item.publishTime);

  return (
    <Link href={`/items/${item.id}`}>
      <Card
        className={cn(
          "group border-border/50 bg-card/50 hover:bg-accent/50 transition-all duration-200",
          "hover:shadow-lg hover:shadow-blue-500/5 hover:border-blue-500/20",
          compact ? "py-2" : ""
        )}
      >
        <CardContent className={cn("p-4", compact && "py-2 px-4")}>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs text-muted-foreground font-mono">
              {timeAgo}
            </span>
            <span className="text-xs text-muted-foreground">·</span>
            <span className="text-xs text-muted-foreground truncate max-w-[120px]">
              {item.source}
            </span>
            <HotScore score={item.hotScore} />
          </div>

          <h3
            className={cn(
              "font-semibold leading-snug mb-1 group-hover:text-blue-500 transition-colors",
              compact ? "text-sm line-clamp-1" : "text-base line-clamp-2"
            )}
          >
            {item.title}
          </h3>

          {!compact && (
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
              {item.summary}
            </p>
          )}

          <div className="flex items-center gap-1.5 flex-wrap">
            <TypeBadge type={item.type} />
            {item.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="text-xs text-muted-foreground bg-muted/50 px-1.5 py-0.5 rounded"
              >
                {tag}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

interface DateDividerProps {
  date: string;
}

export function DateDivider({ date }: DateDividerProps) {
  return (
    <div className="flex items-center gap-3 py-3">
      <div className="flex items-center gap-1 text-muted-foreground">
        <span className="text-xs">✦</span>
        <span className="text-xs font-medium">{date}</span>
        <span className="text-xs">✦</span>
      </div>
      <div className="flex-1 h-px bg-border/50" />
    </div>
  );
}
