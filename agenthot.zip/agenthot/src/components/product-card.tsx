"use client";

import { AgentProduct, CATEGORY_LABELS } from "@/data/types";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { HotScore, CategoryBadge } from "@/components/badges";
import { ExternalLink, Sparkles, Star, GitBranch } from "lucide-react";
import { formatStars } from "@/lib/date";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: AgentProduct;
  onAnalysis?: (product: AgentProduct) => void;
}

export function ProductCard({ product, onAnalysis }: ProductCardProps) {
  return (
    <Card
      className={cn(
        "group border-border/50 bg-card/50 hover:bg-accent/50 transition-all duration-300",
        "hover:shadow-lg hover:shadow-purple-500/5 hover:border-purple-500/20",
        "overflow-hidden"
      )}
    >
      <CardContent className="p-5">
        {/* Header */}
        <div className="flex items-start gap-3 mb-3">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/10 to-blue-500/10 text-2xl border border-border/50">
            {product.logo}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-bold text-base group-hover:text-purple-500 transition-colors truncate">
                {product.name}
              </h3>
              <HotScore score={product.hotScore} />
            </div>
            <CategoryBadge
              category={product.category}
              isDomestic={product.isDomestic}
            />
          </div>
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3 leading-relaxed">
          {product.description}
        </p>

        {/* Tags */}
        <div className="flex items-center gap-1.5 flex-wrap mb-4">
          {product.tags.map((tag) => (
            <span
              key={tag}
              className="text-xs text-muted-foreground bg-muted/50 px-2 py-0.5 rounded-md"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 pt-3 border-t border-border/30">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 text-xs gap-1.5 hover:bg-purple-500/10 hover:text-purple-500"
            onClick={() => onAnalysis?.(product)}
          >
            <Sparkles className="h-3.5 w-3.5" />
            AI 分析
          </Button>

          {product.website && (
            <a
              href={product.website}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button
                size="sm"
                variant="ghost"
                className="h-8 text-xs gap-1.5"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                访问
              </Button>
            </a>
          )}

          {product.github && (
            <a
              href={product.github}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button
                size="sm"
                variant="ghost"
                className="h-8 text-xs gap-1.5"
              >
                <GitBranch className="h-3.5 w-3.5" />
                GitHub
              </Button>
            </a>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

interface ProductAnalysisPanelProps {
  product: AgentProduct;
  isGenerating?: boolean;
  analysis?: {
    positioning: string;
    coreFeatures: string[];
    techArchitecture: string;
    competitors: string[];
    strengths: string[];
    weaknesses: string[];
    useCases: string[];
    overallRating: number;
  };
}

export function ProductAnalysisPanel({
  product,
  isGenerating,
  analysis,
}: ProductAnalysisPanelProps) {
  if (isGenerating) {
    return (
      <div className="space-y-4 animate-pulse">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-purple-500 animate-spin" />
          <span className="text-sm text-purple-500 font-medium">
            AI 正在分析 {product.name}...
          </span>
        </div>
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className="h-16 bg-muted/50 rounded-lg"
            />
          ))}
        </div>
      </div>
    );
  }

  if (!analysis) return null;

  const ratingColor =
    analysis.overallRating >= 8
      ? "text-green-500"
      : analysis.overallRating >= 6
        ? "text-yellow-500"
        : "text-red-500";

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-purple-500" />
          <span className="text-sm font-semibold">
            AI 产品分析报告
          </span>
        </div>
        <div className="flex items-center gap-1">
          <Star className={cn("h-4 w-4", ratingColor)} />
          <span className={cn("text-lg font-bold", ratingColor)}>
            {analysis.overallRating}
          </span>
          <span className="text-xs text-muted-foreground">/10</span>
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-3">
        <AnalysisSection title="产品定位" content={analysis.positioning} />
        <AnalysisSection
          title="核心功能"
          items={analysis.coreFeatures}
        />
        <AnalysisSection title="技术架构" content={analysis.techArchitecture} />
        <AnalysisSection
          title="竞品对比"
          items={analysis.competitors}
        />
        <AnalysisSection
          title="优势"
          items={analysis.strengths}
          type="strength"
        />
        <AnalysisSection
          title="不足"
          items={analysis.weaknesses}
          type="weakness"
        />
        <AnalysisSection
          title="适用场景"
          items={analysis.useCases}
        />
      </div>
    </div>
  );
}

function AnalysisSection({
  title,
  content,
  items,
  type,
}: {
  title: string;
  content?: string;
  items?: string[];
  type?: "strength" | "weakness";
}) {
  return (
    <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
      <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">
        {title}
      </h4>
      {content && (
        <p className="text-sm leading-relaxed">{content}</p>
      )}
      {items && (
        <ul className="space-y-1">
          {items.map((item, i) => (
            <li key={i} className="text-sm flex items-start gap-1.5">
              <span
                className={cn(
                  "mt-1.5 h-1.5 w-1.5 rounded-full flex-shrink-0",
                  type === "strength"
                    ? "bg-green-500"
                    : type === "weakness"
                      ? "bg-red-500"
                      : "bg-blue-500"
                )}
              />
              {item}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
