/**
 * AIHOT (aihot.virxact.com) fetcher
 *
 * Uses the public REST API — no API key needed.
 * Docs: https://aihot.virxact.com/agent
 *
 * API response item fields:
 *   id, title, title_en, url, permalink, source,
 *   publishedAt, discoveredAt, summary, category, score, selected, attribution
 *
 * Category mapping (AIHOT → Agenthot):
 *   ai-models   → model
 *   ai-products → model
 *   industry    → industry
 *   paper       → tips
 *   tip         → tips
 *   (default)   → industry
 */

import type { SourceConfig } from '@/data/rss-sources';
import type { FeedItem } from '@/data/types';

const AIHOT_API_BASE = 'https://aihot.virxact.com/api/public';
const UA = 'agenthot/1.0 (+https://github.com/agenthot)';

interface AihotItem {
  id: string;
  title: string;
  title_en?: string;
  url?: string;
  permalink?: string;
  source?: string;
  publishedAt?: string;
  discoveredAt?: string;
  summary?: string;
  category?: string;
  score?: number;
  selected?: boolean;
  attribution?: { source: string; canonical: string };
}

interface AihotResponse {
  count: number;
  hasNext: boolean;
  nextCursor?: string;
  items: AihotItem[];
}

function mapCategory(
  aihotCategory: string | undefined
): 'model' | 'product' | 'industry' | 'tips' {
  switch (aihotCategory) {
    case 'ai-models':
    case 'ai-products':
      return 'model';
    case 'industry':
      return 'industry';
    case 'paper':
    case 'tip':
      return 'tips';
    default:
      return 'industry';
  }
}

function buildRecommendation(item: AihotItem): string {
  const cat = mapCategory(item.category);
  const catLabel =
    cat === 'model' ? '模型/产品' : cat === 'tips' ? '技巧/论文' : '行业';
  const score = item.score ?? 0;
  const src = item.source ?? 'AIHOT';
  return `本文由 AIHOT 精选自「${src}」，属于 ${catLabel} 类动态，综合热度评分 ${score}/100。内容经 AI 筛选，已过滤低质噪声。`;
}

export async function fetchAihot(source: SourceConfig): Promise<FeedItem[]> {
  const take = 60; // grab top 60 selected items
  const url = `${AIHOT_API_BASE}/items?mode=selected&take=${take}`;

  let data: AihotResponse;
  try {
    const res = await fetch(url, {
      headers: { 'User-Agent': UA },
      signal: AbortSignal.timeout(15_000),
      next: { revalidate: 0 },
    });
    if (!res.ok) {
      console.warn(`[aihot] HTTP ${res.status}`);
      return [];
    }
    data = (await res.json()) as AihotResponse;
  } catch (err) {
    console.warn('[aihot] fetch error:', err);
    return [];
  }

  const now = new Date();
  const items: FeedItem[] = [];

  for (const it of data.items ?? []) {
    const publishTime =
      it.publishedAt ?? it.discoveredAt ?? now.toISOString();
    const type = mapCategory(it.category);
    const summary = it.summary ?? '';
    const content =
      summary ||
      it.title_en ||
      '暂无正文内容，请访问原文链接阅读完整文章。';

    items.push({
      id: `aihot-${it.id}`,
      type,
      title: it.title,
      summary,
      source: it.source ? `AIHOT · ${it.source}` : 'AIHOT',
      hotScore: Math.min(100, (it.score ?? 50) + 5), // slight boost for curated
      publishTime,
      tags: buildTags(it),
      url: it.url,
      recommendation: buildRecommendation(it),
      aiSummary: summary || '暂无 AI 摘要，请阅读原文获取完整信息。',
      content,
    });
  }

  return items;
}

function buildTags(item: AihotItem): string[] {
  const tags: string[] = [];
  if (item.category) tags.push(item.category);
  if (item.title) {
    const lower = item.title.toLowerCase();
    const keywords = [
      'agent', 'gpt', 'claude', 'gemini', 'llm', 'mcp',
      '智能体', '大模型', 'openai', 'anthropic', 'deepseek',
      'kimi', 'qwen', 'rag', 'fine-tuning', 'prompt',
    ];
    for (const kw of keywords) {
      if (lower.includes(kw)) tags.push(kw);
    }
  }
  return [...new Set(tags)].slice(0, 5);
}
