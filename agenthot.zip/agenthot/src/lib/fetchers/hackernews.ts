import type { SourceConfig } from '@/data/rss-sources';
import type { FeedItem } from '@/data/types';

/**
 * Hacker News fetcher.
 *
 * 1. GET /v0/topstories.json → list of top story IDs
 * 2. For the first 50 IDs, GET /v0/item/{id}.json → full story
 * 3. Filter stories whose title matches AI/agent keywords
 *
 * HN API is free and unauthenticated, but we limit concurrency to 8 to be polite.
 */
export async function fetchHackerNews(source: SourceConfig): Promise<FeedItem[]> {
  try {
    // 1. Fetch top story IDs
    const topRes = await fetch(source.url, {
      signal: AbortSignal.timeout(15_000),
      headers: { Accept: 'application/json' },
    });
    if (!topRes.ok) {
      console.warn(`[hackernews] topstories HTTP ${topRes.status}`);
      return [];
    }
    const topIds: number[] = await topRes.json();
    if (!Array.isArray(topIds) || topIds.length === 0) return [];

    // 2. Fetch first 50 items with limited concurrency
    const limit = 50;
    const slice = topIds.slice(0, limit);
    const items = await pMap(slice, fetchHnItem, { concurrency: 8 });

    // 3. Filter to AI/agent-related
    const keywords = source.agentKeywords;
    const keywordRegex = new RegExp(
      `\\b(${keywords.map(escapeRegex).join('|')})`,
      'i'
    );

    const filtered = items
      .filter((it): it is HnItem & { title: string } => !!it && typeof it.title === 'string')
      .filter((it) => keywordRegex.test(it.title));

    // 4. Convert to FeedItem
    return filtered.map((it) => toFeedItem(it, source));
  } catch (err) {
    console.warn(
      `[hackernews] fetch failed:`,
      err instanceof Error ? err.message : err
    );
    return [];
  }
}

interface HnItem {
  id: number;
  type?: string;
  title?: string;
  url?: string;
  by?: string;
  score?: number;
  time?: number; // unix seconds
  descendants?: number;
  text?: string;
}

async function fetchHnItem(id: number): Promise<HnItem | null> {
  try {
    const res = await fetch(
      `https://hacker-news.firebaseio.com/v0/item/${id}.json`,
      {
        signal: AbortSignal.timeout(10_000),
        headers: { Accept: 'application/json' },
      }
    );
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

function toFeedItem(it: HnItem, source: SourceConfig): FeedItem {
  const url = it.url || `https://news.ycombinator.com/item?id=${it.id}`;
  const title = it.title || '(untitled)';
  const summary = it.text
    ? it.text.slice(0, 300)
    : `${it.score ?? 0} points · ${it.descendants ?? 0} comments on Hacker News`;
  const publishTime = it.time
    ? new Date(it.time * 1000).toISOString()
    : new Date().toISOString();

  return {
    id: `hn-${it.id}`,
    type: 'tips',
    title,
    summary,
    source: 'Hacker News',
    hotScore: 0,
    publishTime,
    tags: extractTags(title, source.agentKeywords),
    url,
    recommendation: `Hacker News 热门讨论（${it.score ?? 0} 分 · ${it.descendants ?? 0} 评论）。`,
    aiSummary: summary,
    content: summary,
  };
}

function extractTags(title: string, keywords: string[]): string[] {
  const lower = title.toLowerCase();
  const matched = keywords.filter((kw) => lower.includes(kw.toLowerCase()));
  return [...new Set(matched)].slice(0, 5);
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Minimal p-map implementation.
 * Runs `worker` over `items` with at most `concurrency` in flight.
 */
async function pMap<T, R>(
  items: T[],
  worker: (item: T) => Promise<R>,
  { concurrency }: { concurrency: number }
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let cursor = 0;

  async function run() {
    while (true) {
      const idx = cursor++;
      if (idx >= items.length) return;
      results[idx] = await worker(items[idx]);
    }
  }

  const workers = Array.from(
    { length: Math.min(concurrency, items.length) },
    () => run()
  );
  await Promise.all(workers);
  return results;
}