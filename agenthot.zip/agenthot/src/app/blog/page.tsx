"use client";

import { useState } from "react";
import { useGitHubProjects } from "@/lib/hooks";
import { blogProjects as allBlogProjects } from "@/data/product-data";
import { BlogProject, BLOG_CATEGORY_LABELS } from "@/data/types";
import { BlogCard } from "@/components/blog-card";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner, DataStatus } from "@/components/loading";
import { GitBranch, Search, TrendingUp, Clock, Star, AlertTriangle } from "lucide-react";
import { formatStars } from "@/lib/date";
import { cn } from "@/lib/utils";

const blogCategoryFilters = [
  { value: "all", label: "全部项目" },
  { value: "coding", label: "Coding Agent" },
  { value: "video", label: "Video Agent" },
  { value: "voice", label: "Voice Agent" },
  { value: "framework", label: "Agent Framework" },
  { value: "tool", label: "Agent Tool" },
  { value: "mcp", label: "MCP Server" },
];

const sortOptions = [
  { value: "stars", label: "Star 数" },
  { value: "updated", label: "最近更新" },
  { value: "name", label: "名称" },
];

export default function BlogPage() {
  const [category, setCategory] = useState("all");
  const [sort, setSort] = useState("stars");
  const [searchQuery, setSearchQuery] = useState("");

  const { projects, total, cached, fallback, isLoading, isError, mutate } = useGitHubProjects({
    category,
    sort,
    search: searchQuery,
    limit: 30,
  });

  const displayProjects: BlogProject[] = projects.length > 0
    ? projects
    : allBlogProjects;

  // Stats
  const allProjects = projects.length > 0 ? projects : allBlogProjects;
  const totalStars = allProjects.reduce((sum, p) => sum + p.stars, 0);
  const topProjects = [...allProjects].sort((a, b) => b.stars - a.stars).slice(0, 5);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <GitBranch className="h-5 w-5 text-green-500" />
          <h1 className="text-xl font-bold">Agent 开源项目</h1>
          <Badge variant="secondary" className="text-xs">
            {displayProjects.length} 个项目
          </Badge>
          <Badge variant="outline" className="text-xs bg-green-500/10 text-green-500 border-green-500/20">
            数据来源 GitHub
          </Badge>
          {fallback && (
            <Badge variant="outline" className="text-xs bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
              API 限流，使用缓存
            </Badge>
          )}
        </div>
        {projects.length > 0 && (
          <DataStatus cached={cached} lastUpdated={new Date().toISOString()} onRefresh={() => mutate()} isLoading={isLoading} />
        )}
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
          <div className="text-xs text-muted-foreground">总项目数</div>
          <div className="text-lg font-bold">{allProjects.length}</div>
        </div>
        <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
          <div className="text-xs text-muted-foreground">总 Star 数</div>
          <div className="text-lg font-bold">{formatStars(totalStars)}</div>
        </div>
        <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
          <div className="text-xs text-muted-foreground">热门项目</div>
          <div className="text-lg font-bold">{topProjects[0]?.name}</div>
        </div>
        <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
          <div className="text-xs text-muted-foreground">主要语言</div>
          <div className="text-lg font-bold">Python</div>
        </div>
      </div>

      {/* Top 5 Trending */}
      <div className="mb-6 p-4 rounded-xl bg-gradient-to-r from-green-500/5 to-emerald-600/5 border border-green-500/10">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="h-4 w-4 text-green-500" />
          <h2 className="text-sm font-bold">最热门 Agent 项目 TOP 5</h2>
        </div>
        <div className="space-y-2">
          {topProjects.map((project, index) => (
            <div
              key={project.id}
              className="flex items-center gap-3 py-1.5 px-2 rounded-lg hover:bg-accent/50 transition-colors"
            >
              <span
                className={cn(
                  "text-sm font-bold w-5 text-center",
                  index < 3 ? "text-green-500" : "text-muted-foreground"
                )}
              >
                {index + 1}
              </span>
              <span className="text-sm font-medium flex-1 truncate">
                {project.name}
              </span>
              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                <Star className="h-3 w-3 text-yellow-500" />
                {formatStars(project.stars)}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <aside className="w-full lg:w-56 flex-shrink-0 space-y-4">
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              分类筛选
            </h3>
            <div className="space-y-1">
              {blogCategoryFilters.map((filter) => {
                const count =
                  filter.value === "all"
                    ? allProjects.length
                    : allProjects.filter((p) => p.category === filter.value).length;
                return (
                  <button
                    key={filter.value}
                    onClick={() => setCategory(filter.value)}
                    className={cn(
                      "w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors",
                      category === filter.value
                        ? "bg-green-500/10 text-green-500 font-medium"
                        : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                    )}
                  >
                    {filter.label}
                    <span className="text-xs">{count}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              排序
            </h3>
            <div className="space-y-1">
              {sortOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => setSort(option.value)}
                  className={cn(
                    "w-full flex items-center gap-2 px-3 py-2 text-sm rounded-lg transition-colors",
                    sort === option.value
                      ? "bg-green-500/10 text-green-500 font-medium"
                      : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                  )}
                >
                  {option.value === "stars" && <Star className="h-3.5 w-3.5" />}
                  {option.value === "updated" && <Clock className="h-3.5 w-3.5" />}
                  {option.value === "name" && <GitBranch className="h-3.5 w-3.5" />}
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Search */}
          <div className="flex items-center gap-3 mb-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="搜索 Agent 开源项目..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-9 pl-9 pr-3 text-sm rounded-lg border border-border/50 bg-muted/50 placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-green-500/30"
              />
            </div>
          </div>

          {/* Loading */}
          {isLoading && projects.length === 0 && (
            <LoadingSpinner message="正在从 GitHub 获取项目数据..." />
          )}

          {/* Error */}
          {isError && projects.length === 0 && (
            <div className="text-center py-8">
              <AlertTriangle className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">GitHub API 请求受限，显示缓存数据</p>
            </div>
          )}

          {/* Project Grid */}
          {!isLoading && (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
              {displayProjects.map((project) => (
                <BlogCard key={project.id} project={project} />
              ))}
            </div>
          )}

          {!isLoading && displayProjects.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-sm">暂无相关 Agent 开源项目</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
