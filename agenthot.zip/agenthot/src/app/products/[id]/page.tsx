import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink, Star, Globe, GitBranch, Calendar, Building2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { CategoryBadge, HotScore } from "@/components/badges";
import { agentProducts } from "@/data/product-data";
import { ProductAnalysisPanel } from "@/components/product-card";
import Link from "next/link";

export function generateStaticParams() {
  return agentProducts.map((p) => ({ id: p.id }));
}

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const product = agentProducts.find((p) => p.id === id);

  if (!product) {
    notFound();
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top bar */}
      <div className="flex items-center justify-between mb-6">
        <Link href="/products">
          <Button variant="ghost" size="sm" className="gap-1.5">
            <ArrowLeft className="h-4 w-4" />
            返回产品列表
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          {product.website && (
            <a href={product.website} target="_blank" rel="noopener noreferrer">
              <Button variant="ghost" size="sm" className="gap-1.5">
                <Globe className="h-4 w-4" />
                官网
              </Button>
            </a>
          )}
          {product.github && (
            <a href={product.github} target="_blank" rel="noopener noreferrer">
              <Button variant="ghost" size="sm" className="gap-1.5">
                <GitBranch className="h-4 w-4" />
                GitHub
              </Button>
            </a>
          )}
        </div>
      </div>

      {/* Header */}
      <div className="flex items-start gap-4 mb-6">
        <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500/10 to-blue-500/10 text-3xl border border-border/50">
          {product.logo}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-2xl font-bold">{product.name}</h1>
            <HotScore score={product.hotScore} />
          </div>
          <CategoryBadge category={product.category} isDomestic={product.isDomestic} />
        </div>
      </div>

      {/* Meta Info */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <Building2 className="h-3 w-3" />所属公司
          </div>
          <div className="text-sm font-medium mt-1">{product.company}</div>
        </div>
        <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <Calendar className="h-3 w-3" />成立时间
          </div>
          <div className="text-sm font-medium mt-1">{product.foundedYear}</div>
        </div>
        <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <Star className="h-3 w-3" />定价
          </div>
          <div className="text-sm font-medium mt-1">{product.pricing}</div>
        </div>
        <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <Globe className="h-3 w-3" />地区
          </div>
          <div className="text-sm font-medium mt-1">{product.isDomestic ? "国内" : "海外"}</div>
        </div>
      </div>

      {/* Tags */}
      <div className="flex items-center gap-2 flex-wrap mb-6">
        {product.tags.map((tag) => (
          <Badge key={tag} variant="secondary" className="text-xs">
            {tag}
          </Badge>
        ))}
      </div>

      <Separator className="my-6" />

      {/* Full Description */}
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-3">产品介绍</h2>
        <p className="text-sm leading-relaxed">{product.fullDescription}</p>
      </div>

      {/* Key Features */}
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-3">核心功能</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {product.keyFeatures.map((feature, i) => (
            <div key={i} className="flex items-start gap-2 p-3 rounded-lg bg-muted/30 border border-border/30">
              <span className="text-blue-500 font-bold text-sm">{i + 1}</span>
              <span className="text-sm">{feature}</span>
            </div>
          ))}
        </div>
      </div>

      <Separator className="my-6" />

      {/* AI Analysis */}
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <span className="text-purple-500">✨</span>
          AI 产品分析
        </h2>
        <ProductAnalysisPanel
          product={product}
          analysis={{
            positioning: product.fullDescription,
            coreFeatures: product.keyFeatures,
            techArchitecture: `${product.name} 采用主流 LLM + Agent 框架构建，支持 MCP 工具协议和多模型切换。${product.isDomestic ? '中文场景做了深度优化' : '国际化生态成熟'}。`,
            competitors: agentProducts
              .filter((p) => p.category === product.category && p.id !== product.id)
              .slice(0, 3)
              .map((p) => p.name),
            strengths: [
              `${product.tags[0]} 领域专业性强`,
              `${product.isDomestic ? '中文场景表现优异' : '国际化生态成熟'}`,
              '产品迭代速度快',
              '用户社区活跃',
            ],
            weaknesses: [
              '复杂场景稳定性待提升',
              '长期运行成本较高',
              '定制化能力有限',
              '需要一定的学习成本',
            ],
            useCases: product.tags.map((t) => `${t} 相关场景`),
            overallRating: Math.min(Math.round(product.hotScore / 10), 10),
          }}
        />
      </div>

      <Separator className="my-6" />

      {/* Links */}
      <div className="flex items-center gap-3">
        {product.website && (
          <a href={product.website} target="_blank" rel="noopener noreferrer">
            <Button className="gap-1.5">
              <ExternalLink className="h-4 w-4" />
              访问官网
            </Button>
          </a>
        )}
        {product.github && (
          <a href={product.github} target="_blank" rel="noopener noreferrer">
            <Button variant="outline" className="gap-1.5">
              <GitBranch className="h-4 w-4" />
              GitHub
            </Button>
          </a>
        )}
      </div>
    </div>
  );
}
