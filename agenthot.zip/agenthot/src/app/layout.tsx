import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from "@/components/theme-provider";
import { Header } from "@/components/header";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AGENTHOT - Agent 行业动态聚合",
  description:
    "Agent 行业动态聚合 · 每日精选与深度分析。发现国内外 AI Agent 产品，获取行业动态、开发技巧和开源项目。",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="zh-CN"
      suppressHydrationWarning
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-background text-foreground">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <Header />
          <main className="flex-1">{children}</main>
          <footer className="border-t border-border/50 py-6 text-center text-sm text-muted-foreground">
            <p>AGENTHOT · Agent 行业动态聚合 · 每日精选与深度分析</p>
            <p className="mt-1">© 2026 AGENTHOT. All rights reserved.</p>
          </footer>
        </ThemeProvider>
      </body>
    </html>
  );
}
