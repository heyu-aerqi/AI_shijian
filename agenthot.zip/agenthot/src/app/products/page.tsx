"use client";

import { useState, useCallback } from "react";
import { useAgentProducts } from "@/lib/hooks";
import { agentProducts as allAgentProducts } from "@/data/product-data";
import { AgentProduct, CATEGORY_LABELS } from "@/data/types";
import { ProductCard, ProductAnalysisPanel } from "@/components/product-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sparkles, Search, LayoutGrid, List } from "lucide-react";
import { cn } from "@/lib/utils";

const categoryFilters = [
  { value: "all", label: "全部 Agent" },
  { value: "coding", label: "代码 Agent" },
  { value: "video", label: "视频 Agent" },
  { value: "customer-service", label: "客服 Agent" },
  { value: "marketing", label: "营销 Agent" },
  { value: "data", label: "数据 Agent" },
  { value: "general", label: "通用 Agent" },
  { value: "framework", label: "Agent 框架" },
];

const regionFilters = [
  { value: "all", label: "全部地区" },
  { value: "domestic", label: "国内" },
  { value: "overseas", label: "海外" },
];

// Simulated AI analysis results
const analysisResults: Record<string, {
  positioning: string;
  coreFeatures: string[];
  techArchitecture: string;
  competitors: string[];
  strengths: string[];
  weaknesses: string[];
  useCases: string[];
  overallRating: number;
}> = {
  p1: {
    positioning: "面向开发者的 AI-First 代码编辑器，定位为程序员的生产力倍增器，通过 Agent 模式实现从理解需求到代码实现的自动化。",
    coreFeatures: ["项目级上下文理解", "跨文件自动重构", "自然语言代码编辑", "终端集成操作", "智能代码补全"],
    techArchitecture: "基于 VS Code 内核构建，集成自研 AI 引擎 + 主流 LLM API，支持本地模型部署。Agent 模式采用 ReAct 循环架构。",
    competitors: ["GitHub Copilot", "Windsurf", "Devin", "OpenAI Codex"],
    strengths: ["深度理解项目上下文", "Agent 模式自主完成复杂任务", "IDE 原生体验无缝集成", "支持多种 LLM 后端"],
    weaknesses: ["资源占用较高", "Agent 模式偶有误操作需人工确认", "订阅价格偏高", "团队协作功能待完善"],
    useCases: ["日常编码和代码补全", "大型项目跨文件重构", "根据自然语言描述实现功能", "代码审查和 Bug 修复"],
    overallRating: 9,
  },
  p2: {
    positioning: "全栈自主开发 Agent，定位为 AI 软件工程师，能够独立完成从需求分析到部署上线的完整开发流程。",
    coreFeatures: ["全流程自主开发", "需求理解与拆解", "代码编写与测试", "Bug 自动修复", "部署与运维"],
    techArchitecture: "多模型协同架构，整合代码生成、测试、调试等多个专业子 Agent，通过编排层协调工作。",
    competitors: ["Cursor Agent", "OpenAI Codex Agent", "Devin 2.0", "SWE-Agent"],
    strengths: ["端到端全流程覆盖", "自主性最强", "支持复杂项目级任务", "持续学习能力"],
    weaknesses: ["成本较高", "长任务执行时间较长", "复杂逻辑推理偶有失误", "需要良好的人类监督机制"],
    useCases: ["独立完成小型项目开发", "大型项目功能迭代", "自动化 Bug 修复和测试", "遗留代码迁移和重构"],
    overallRating: 8,
  },
  p3: {
    positioning: "视频创作 Agent，将自然语言描述转化为完整的专业级视频，覆盖从创意到成片的全流程。",
    coreFeatures: ["文字转完整视频", "智能分镜生成", "自动剪辑与配音", "多风格视频生成", "素材智能匹配"],
    techArchitecture: "基于 Gen-4 多模态生成模型，集成视频生成、音频合成、剪辑 Agent 三个子系统，通过工作流引擎协调。",
    competitors: ["Pika Agent", "Synthesia", "HeyGen", "Sora"],
    strengths: ["全流程自动化程度高", "视频质量专业级", "中文场景表现优异", "支持多种视频风格"],
    weaknesses: ["渲染时间较长", "对复杂场景理解有限", "免费额度有限", "部分风格需要付费"],
    useCases: ["企业宣传片快速制作", "社交媒体视频批量生产", "培训视频自动化制作", "广告创意视频生成"],
    overallRating: 8,
  },
};

export default function ProductsPage() {
  const [category, setCategory] = useState("all");
  const [region, setRegion] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [analysisOpen, setAnalysisOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<AgentProduct | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentAnalysis, setCurrentAnalysis] = useState<typeof analysisResults[string] | null>(null);

  const { products, total } = useAgentProducts({
    category,
    region,
    search: searchQuery,
  });

  const handleAnalysis = useCallback((product: AgentProduct) => {
    setSelectedProduct(product);
    setAnalysisOpen(true);
    setIsGenerating(true);
    setCurrentAnalysis(null);

    // Simulate AI analysis
    setTimeout(() => {
      const result = analysisResults[product.id];
      if (result) {
        setCurrentAnalysis(result);
      } else {
        // Generate a generic analysis for products without pre-defined analysis
        setCurrentAnalysis({
          positioning: `${product.name} 是一款${CATEGORY_LABELS[product.category]}产品，${product.description}`,
          coreFeatures: product.tags.map((t) => `${t}能力`),
          techArchitecture: "基于主流 LLM + Agent 框架构建，支持工具调用和多步推理，采用 ReAct 或 Plan-and-Execute 架构模式。",
          competitors: allAgentProducts
            .filter((p) => p.category === product.category && p.id !== product.id)
            .slice(0, 3)
            .map((p) => p.name),
          strengths: [`${product.tags[0]}领域专业性强`, `${product.isDomestic ? '中文场景表现优异' : '国际化生态成熟'}`, "产品迭代速度快", "用户社区活跃"],
          weaknesses: ["复杂场景稳定性待提升", "成本较高", "定制化能力有限", "需要一定的学习成本"],
          useCases: product.tags.map((t) => `${t}相关场景应用`),
          overallRating: Math.round(product.hotScore / 10),
        });
      }
      setIsGenerating(false);
    }, 2000);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <Sparkles className="h-5 w-5 text-purple-500" />
        <h1 className="text-xl font-bold">Agent 产品发现</h1>
        <Badge variant="secondary" className="text-xs">
          {products.length} 款
        </Badge>
        <Badge variant="outline" className="text-xs bg-purple-500/10 text-purple-500 border-purple-500/20">
          支持 AI 分析
        </Badge>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <aside className="w-full lg:w-56 flex-shrink-0 space-y-4">
          {/* Category Filter */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              分类筛选
            </h3>
            <div className="space-y-1">
              {categoryFilters.map((filter) => {
                const count =
                  filter.value === "all"
                    ? allAgentProducts.length
                    : allAgentProducts.filter(
                        (p) => p.category === filter.value
                      ).length;
                return (
                  <button
                    key={filter.value}
                    onClick={() => setCategory(filter.value)}
                    className={cn(
                      "w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors",
                      category === filter.value
                        ? "bg-purple-500/10 text-purple-500 font-medium"
                        : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                    )}
                  >
                    {filter.label}
                    <span className="text-xs">{count}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Region Filter */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              地区
            </h3>
            <div className="flex items-center gap-1">
              {regionFilters.map((filter) => (
                <button
                  key={filter.value}
                  onClick={() => setRegion(filter.value)}
                  className={cn(
                    "px-3 py-1.5 text-xs font-medium rounded-lg transition-colors",
                    region === filter.value
                      ? "bg-purple-500/10 text-purple-500 border border-purple-500/20"
                      : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                  )}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="p-3 rounded-lg bg-muted/30 border border-border/30">
            <div className="text-xs text-muted-foreground space-y-1.5">
              <div className="flex justify-between">
                <span>国内产品</span>
                <span className="font-medium text-foreground">
                  {allAgentProducts.filter((p) => p.isDomestic).length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>海外产品</span>
                <span className="font-medium text-foreground">
                  {allAgentProducts.filter((p) => !p.isDomestic).length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>总产品数</span>
                <span className="font-medium text-foreground">
                  {allAgentProducts.length}
                </span>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Search + View Toggle */}
          <div className="flex items-center gap-3 mb-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="搜索 Agent 产品..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-9 pl-9 pr-3 text-sm rounded-lg border border-border/50 bg-muted/50 placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-purple-500/30"
              />
            </div>
            <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-0.5">
              <Button
                size="icon"
                variant={viewMode === "grid" ? "secondary" : "ghost"}
                className="h-7 w-7"
                onClick={() => setViewMode("grid")}
              >
                <LayoutGrid className="h-3.5 w-3.5" />
              </Button>
              <Button
                size="icon"
                variant={viewMode === "list" ? "secondary" : "ghost"}
                className="h-7 w-7"
                onClick={() => setViewMode("list")}
              >
                <List className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>

          {/* Products Grid/List */}
          {viewMode === "grid" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAnalysis={handleAnalysis}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAnalysis={handleAnalysis}
                />
              ))}
            </div>
          )}

          {products.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-sm">暂无相关 Agent 产品</p>
            </div>
          )}
        </div>
      </div>

      {/* AI Analysis Dialog */}
      <Dialog open={analysisOpen} onOpenChange={setAnalysisOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <span className="text-xl">{selectedProduct?.logo}</span>
              <span>{selectedProduct?.name} - AI 产品分析</span>
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <ProductAnalysisPanel
              product={selectedProduct!}
              isGenerating={isGenerating}
              analysis={currentAnalysis || undefined}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
