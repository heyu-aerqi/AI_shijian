"use client";

import { useState, useMemo } from "react";
import { useFeedItems } from "@/lib/hooks";
import { feedItems } from "@/data/feed-data";
import { FeedCard, DateDivider } from "@/components/feed-card";
import { TypeBadge } from "@/components/badges";
import { LoadingSpinner, DataStatus } from "@/components/loading";
import { formatDate } from "@/lib/date";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Zap } from "lucide-react";
import { FeedItem } from "@/data/types";

const typeFilters = [
  { value: "all", label: "全部" },
  { value: "model", label: "模型" },
  { value: "product", label: "产品" },
  { value: "industry", label: "行业" },
  { value: "tips", label: "技巧" },
];

export default function HomePage() {
  const [activeType, setActiveType] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { items, total, cached, lastUpdated, isLoading, mutate } = useFeedItems({
    type: activeType,
    search: searchQuery,
    limit: 100,
  });

  // Use real data if available, otherwise fallback to mock
  const displayItems: FeedItem[] = items.length > 0 ? items : feedItems;

  // Client-side filter for type (API also filters, but keep for fallback)
  const filteredItems = useMemo(() => {
    let filtered = displayItems;

    if (activeType !== "all" && items.length === 0) {
      filtered = filtered.filter((item) => item.type === activeType);
    }

    if (searchQuery && items.length === 0) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.summary.toLowerCase().includes(q) ||
          item.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    return filtered.sort(
      (a, b) =>
        new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime()
    );
  }, [displayItems, activeType, searchQuery, items.length]);

  // Group by date
  const groupedItems = useMemo(() => {
    const groups: Record<string, FeedItem[]> = {};
    filteredItems.forEach((item) => {
      const date = formatDate(item.publishTime);
      if (!groups[date]) groups[date] = [];
      groups[date].push(item);
    });
    return groups;
  }, [filteredItems]);

  // Top 5
  const top5 = useMemo(
    () => [...displayItems].sort((a, b) => b.hotScore - a.hotScore).slice(0, 5),
    [displayItems]
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Hero Stats */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-blue-500" />
            <h1 className="text-xl font-bold">全部 Agent 动态</h1>
            <Badge variant="secondary" className="text-xs">
              今日 {displayItems.length} 条
            </Badge>
          </div>
          {items.length > 0 && (
            <DataStatus
              cached={cached}
              lastUpdated={lastUpdated}
              onRefresh={() => mutate()}
              isLoading={isLoading}
            />
          )}
        </div>
      </div>

      {/* Top 5 Hot */}
      <div className="mb-8 p-4 rounded-xl bg-gradient-to-r from-blue-500/5 to-purple-600/5 border border-blue-500/10">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="h-4 w-4 text-red-500" />
          <h2 className="text-sm font-bold">今日热点 TOP 5</h2>
        </div>
        <div className="space-y-2">
          {top5.map((item, index) => (
            <div
              key={item.id}
              className="flex items-center gap-3 py-1.5 px-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer"
            >
              <span
                className={`text-sm font-bold w-5 text-center ${
                  index < 3 ? "text-red-500" : "text-muted-foreground"
                }`}
              >
                {index + 1}
              </span>
              <TypeBadge type={item.type} className="flex-shrink-0" />
              <span className="text-sm flex-1 truncate">{item.title}</span>
              <span className="text-xs text-muted-foreground font-mono">
                {item.hotScore}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Search + Type Filter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 mb-6">
        <div className="relative flex-1 max-w-sm">
          <input
            type="text"
            placeholder="搜索标题、摘要、标签..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-9 px-3 py-2 text-sm rounded-lg border border-border/50 bg-muted/50 placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500/50"
          />
        </div>
        <div className="flex items-center gap-1">
          {typeFilters.map((filter) => (
            <button
              key={filter.value}
              onClick={() => setActiveType(filter.value)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                activeType === filter.value
                  ? "bg-blue-500/10 text-blue-500 border border-blue-500/20"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Loading state */}
      {isLoading && items.length === 0 && <LoadingSpinner message="正在从 RSS 源聚合数据..." />}

      {/* Feed */}
      {!isLoading && (
        <div className="space-y-2">
          {Object.entries(groupedItems).map(([date, items]) => (
            <div key={date}>
              <DateDivider date={date} />
              <div className="space-y-2">
                {items.map((item) => (
                  <FeedCard key={item.id} item={item} />
                ))}
              </div>
            </div>
          ))}
          {filteredItems.length === 0 && !isLoading && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-sm">暂无相关内容</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
