"use client";

import { useTheme } from "next-themes";
import { Moon, Sun, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  useEffect,
  useState,
} from "react";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  if (!mounted) return <div className="w-9 h-9" />;

  const themes = [
    { value: "light", icon: Sun, label: "浅色" },
    { value: "system", icon: Monitor, label: "系统" },
    { value: "dark", icon: Moon, label: "深色" },
  ];

  const current = themes.find((t) => t.value === theme) || themes[1];
  const CurrentIcon = current.icon;

  const cycleTheme = () => {
    const currentIndex = themes.findIndex((t) => t.value === theme);
    const nextIndex = (currentIndex + 1) % themes.length;
    setTheme(themes[nextIndex].value);
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={cycleTheme}
      className="h-9 w-9 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent"
      title={current.label}
    >
      <CurrentIcon className="h-4 w-4" />
    </Button>
  );
}
