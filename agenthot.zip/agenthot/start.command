#!/bin/bash
# AGENTHOT — 一键启动脚本
# 双击此文件即可自动安装依赖并启动开发服务器

cd "$(dirname "$0")"

echo "========================================"
echo "  AGENTHOT — Agent 行业动态聚合"
echo "========================================"
echo ""

# 检查 Node.js
if ! command -v node &> /dev/null; then
  echo "❌ 未检测到 Node.js，请先安装 Node.js (≥ 20.0.0)"
  echo "   下载地址: https://nodejs.org/"
  echo ""
  read -p "按回车键退出..."
  exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
echo "✅ Node.js 版本: $(node -v)"

if [ "$NODE_VERSION" -lt 20 ]; then
  echo "❌ Node.js 版本过低，请升级到 ≥ 20.0.0"
  echo "   下载地址: https://nodejs.org/"
  read -p "按回车键退出..."
  exit 1
fi

# 检查 npm
if ! command -v npm &> /dev/null; then
  echo "❌ 未检测到 npm，请确认 Node.js 安装是否完整"
  read -p "按回车键退出..."
  exit 1
fi
echo "✅ npm 版本: $(npm -v)"
echo ""

# 安装依赖
if [ ! -d "node_modules" ]; then
  echo "📦 首次运行，正在安装依赖（可能需要 1-3 分钟）..."
  echo ""
  npm install
  if [ $? -ne 0 ]; then
    echo ""
    echo "❌ 依赖安装失败，请检查网络连接后重试"
    read -p "按回车键退出..."
    exit 1
  fi
  echo ""
  echo "✅ 依赖安装完成！"
  echo ""
else
  echo "✅ 依赖已安装，跳过安装步骤"
  echo ""
fi

# 启动开发服务器
echo "🚀 启动开发服务器..."
echo "   浏览器访问: http://localhost:3000"
echo "   按 Ctrl+C 停止服务器"
echo ""

# 尝试自动打开浏览器（延迟 3 秒等服务器启动）
( sleep 3 && open http://localhost:3000 2>/dev/null ) &

npm run dev
