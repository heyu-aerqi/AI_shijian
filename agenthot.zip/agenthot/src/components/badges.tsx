"use client";

import { Badge } from "@/components/ui/badge";
import { Flame } from "lucide-react";
import { TYPE_LABELS } from "@/data/types";
import { cn } from "@/lib/utils";

interface HotScoreProps {
  score: number;
  className?: string;
}

export function HotScore({ score, className }: HotScoreProps) {
  const level =
    score >= 90 ? "hot" : score >= 70 ? "warm" : "normal";
  const colorMap = {
    hot: "text-red-500",
    warm: "text-orange-500",
    normal: "text-muted-foreground",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 text-xs font-medium",
        colorMap[level],
        className
      )}
    >
      <Flame className={cn("h-3 w-3", level === "hot" && "animate-pulse")} />
      {score}
    </span>
  );
}

interface TypeBadgeProps {
  type: string;
  className?: string;
}

export function TypeBadge({ type, className }: TypeBadgeProps) {
  const colorMap: Record<string, string> = {
    model: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    product: "bg-purple-500/10 text-purple-500 border-purple-500/20",
    industry: "bg-green-500/10 text-green-500 border-green-500/20",
    tips: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  };

  return (
    <Badge
      variant="outline"
      className={cn(
        "text-xs px-2 py-0.5 font-medium border",
        colorMap[type] || "bg-muted text-muted-foreground",
        className
      )}
    >
      {TYPE_LABELS[type] || type}
    </Badge>
  );
}

interface CategoryBadgeProps {
  category: string;
  isDomestic?: boolean;
  className?: string;
}

export function CategoryBadge({
  category,
  isDomestic,
  className,
}: CategoryBadgeProps) {
  const CATEGORY_LABELS: Record<string, string> = {
    video: "视频 Agent",
    coding: "代码 Agent",
    "customer-service": "客服 Agent",
    marketing: "营销 Agent",
    data: "数据 Agent",
    general: "通用 Agent",
    framework: "Agent 框架",
    other: "其他 Agent",
  };

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <Badge variant="secondary" className="text-xs">
        {CATEGORY_LABELS[category] || category}
      </Badge>
      {isDomestic !== undefined && (
        <Badge
          variant="outline"
          className={cn(
            "text-xs",
            isDomestic
              ? "bg-red-500/10 text-red-400 border-red-500/20"
              : "bg-blue-500/10 text-blue-400 border-blue-500/20"
          )}
        >
          {isDomestic ? "国内" : "海外"}
        </Badge>
      )}
    </div>
  );
}
