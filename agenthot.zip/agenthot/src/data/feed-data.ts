import { FeedItem, AgentProduct, BlogProject } from './types';

export const feedItems: FeedItem[] = [
  {
    id: '1',
    type: 'product',
    title: 'OpenAI 发布 Codex Agent：可自主完成代码编写与调试的全栈 Agent',
    summary: 'OpenAI 正式推出 Codex Agent，这是一款能够自主完成代码编写、测试和调试的 AI Agent 产品。该产品基于 GPT-5 架构，支持多文件编辑、终端操作和 Git 提交，标志着 AI Agent 从辅助工具迈向自主开发的新阶段。',
    source: 'OpenAI Blog',
    hotScore: 98,
    publishTime: '2026-07-23T09:00:00Z',
    tags: ['OpenAI', 'Codex', '代码Agent', '自主开发'],
    url: 'https://openai.com/blog/codex-agent',
    recommendation: '这是代码 Agent 领域的里程碑产品。Codex Agent 不再只是代码补全工具，而是能够理解需求、规划方案、编写代码、运行测试的完整自主 Agent。它的发布意味着 AI Agent 正式进入"可替代初级开发者"的阶段，对整个软件开发行业影响深远。',
    aiSummary: 'Codex Agent 是 OpenAI 推出的全栈自主代码 Agent，核心能力包括：1) 需求理解与任务规划；2) 多文件协同编辑；3) 自动化测试与调试；4) Git 操作与代码审查。采用 ReAct 循环架构，支持人类确认步骤。定价 Pro 版每月 $200，Enterprise 版按用量计费。',
    content: `OpenAI 今日正式发布 Codex Agent，这是其迄今为止最强大的代码 Agent 产品。

核心能力
Codex Agent 能够自主完成以下任务：
- 需求理解：从自然语言描述中提取开发需求，拆解为具体任务
- 代码编写：支持多文件协同编辑，理解项目整体架构
- 自动测试：编写并运行单元测试、集成测试，自动修复失败用例
- 调试修复：分析错误日志，定位问题，提出并实施修复方案
- Git 操作：自动提交、创建 PR、处理 Code Review 意见

技术架构
Codex Agent 基于 GPT-5 架构，采用 ReAct (Reason + Act) 循环模式：
1. 理解任务 → 2. 制定计划 → 3. 执行操作 → 4. 观察结果 → 5. 调整策略

每一步都支持人类确认介入，确保 Agent 不会执行危险操作。

定价
- Pro 版：$200/月，包含 100 次自主任务
- Enterprise 版：按用量计费，支持私有化部署
- API 版：按 token 计费，可集成到现有工具链

与 Cursor Agent、Devin 等竞品相比，Codex Agent 的优势在于更强的推理能力和与 OpenAI 生态的深度集成。`,
  },
  {
    id: '2',
    type: 'model',
    title: 'Claude 5 Opus 发布：专为 Agent 工作流优化的推理模型',
    summary: 'Anthropic 发布 Claude 5 Opus，在复杂推理和长上下文理解方面取得重大突破，特别针对 Agent 场景进行了优化，支持更长的工具调用链和更稳定的任务执行。',
    source: 'Anthropic Blog',
    hotScore: 95,
    publishTime: '2026-07-23T08:00:00Z',
    tags: ['Anthropic', 'Claude', 'Agent模型', '推理'],
    url: 'https://anthropic.com/blog/claude-5-opus',
    recommendation: 'Claude 5 Opus 是目前最适合 Agent 开发的模型之一。它在工具调用准确率、长链推理稳定性和指令遵循方面都有显著提升，这些都是构建可靠 Agent 系统的关键能力。',
    aiSummary: 'Claude 5 Opus 针对 Agent 场景做了三大优化：1) 工具调用准确率提升至 98.5%；2) 支持 50+ 步骤的连续工具调用链；3) 新增 Agent 模式系统提示词，自动进入规划-执行循环。上下文窗口 200K tokens，定价 $15/M input tokens。',
    content: `Anthropic 今日发布 Claude 5 Opus，这是其旗舰模型的最新版本，专门针对 Agent 工作流进行了深度优化。

Agent 核心优化
1. 工具调用准确率 98.5%
Claude 5 Opus 在 Agent 场景中最关键的工具调用方面达到了业界领先的准确率。在 Berkeley Function Calling Benchmark 上得分 98.5%，显著超过上一代的 94.2%。

2. 超长工具调用链
支持 50+ 步骤的连续工具调用，不丢失上下文。这对于复杂的 Agent 任务（如多步调研、跨系统操作）至关重要。

3. Agent 模式系统提示词
新增内置的 Agent 模式，模型会自动进入"规划-执行-观察-调整"的循环，无需开发者手动编写复杂的 Agent 编排逻辑。

定价与可用性
- Input: $15/M tokens
- Output: $75/M tokens
- 已在 Claude API 和 Amazon Bedrock 上线`,
  },
  {
    id: '3',
    type: 'product',
    title: 'Runway Gen-4 Agent：从文字描述到完整视频的全自动 Agent',
    summary: 'Runway 发布 Gen-4 Agent，用户只需提供文字描述，Agent 即可自动完成分镜、生成、剪辑、配音的完整视频制作流程，这是视频 Agent 领域的重大突破。',
    source: 'Runway Blog',
    hotScore: 92,
    publishTime: '2026-07-23T07:30:00Z',
    tags: ['Runway', '视频Agent', 'AIGC', '视频制作'],
    url: 'https://runway.com/blog/gen4-agent',
    recommendation: '视频制作是最复杂的创作流程之一，Gen-4 Agent 将分镜、生成、剪辑、配音四个环节全部自动化，是视频 Agent 的标杆产品。对内容创作者和企业培训视频制作有颠覆性影响。',
    aiSummary: 'Gen-4 Agent 是首个支持全流程视频制作的 Agent 产品。包含四个子系统：分镜 Agent（理解文字→生成分镜脚本）、生成 Agent（逐镜头生成视频片段）、剪辑 Agent（自动转场/调色/节奏优化）、配音 Agent（旁白生成+音效匹配）。支持 5-30 分钟视频输出。',
    content: `Runway 今日发布 Gen-4 Agent，这是视频 AI 领域的首个全流程自主 Agent 产品。

四大 Agent 子系统

1. 分镜 Agent
从自然语言描述中理解视频需求，自动生成分镜脚本、场景描述和镜头规划。支持风格参考图片作为输入。

2. 生成 Agent
根据分镜脚本逐镜头生成视频片段，支持多种视频风格（写实、动画、3D 等），每段 5-15 秒。

3. 剪辑 Agent
自动处理镜头拼接、转场效果、节奏调整、色彩统一，输出专业的成片效果。

4. 配音 Agent
自动生成旁白、匹配背景音乐和音效，支持中英文双语。

使用流程
用户只需输入："制作一个3分钟的产品介绍视频，展示我们新手机的AI功能"，Agent 即可自动完成全流程制作。

定价
- Starter: $28/月，10条短视频
- Pro: $76/月，50条视频+商用授权
- Enterprise: 定制报价`,
  },
  {
    id: '4',
    type: 'industry',
    title: '2026 年 AI Agent 市场规模预计突破 500 亿美元，企业级应用增长最快',
    summary: '据 Gartner 最新报告，全球 AI Agent 市场规模在 2026 年预计将突破 500 亿美元，其中企业级 Agent 应用（客服、数据分析、代码开发）年增长率达 68%，远超消费级 Agent。',
    source: 'Gartner',
    hotScore: 90,
    publishTime: '2026-07-23T06:00:00Z',
    tags: ['市场报告', 'Gartner', '企业Agent', '市场规模'],
    recommendation: '这份报告是理解 Agent 行业趋势的必读材料。500 亿美元的市场规模和 68% 的增长率说明 Agent 已经从概念验证阶段进入规模化部署阶段，企业级应用是最大的增长引擎。',
    aiSummary: 'Gartner 报告核心数据：1) 2026 年全球 Agent 市场规模 500 亿美元；2) 企业级 Agent 增长率 68%；3) 代码 Agent 占比 25%，客服 Agent 占比 22%；4) 中国市场增速全球第一；5) 到 2028 年 80% 企业将部署至少一个 Agent 应用。',
    content: `Gartner 发布 2026 年 AI Agent 市场报告，以下是核心发现：

市场规模
- 2026 年全球 AI Agent 市场规模预计突破 500 亿美元
- 2024-2026 年 CAGR 为 52%
- 企业级 Agent 应用增长最快，年增长率 68%

细分市场
- 代码 Agent：占比 25%（约 $125 亿），是最大的细分市场
- 客服 Agent：占比 22%（约 $110 亿）
- 数据分析 Agent：占比 18%（约 $90 亿）
- 营销 Agent：占比 15%（约 $75 亿）
- 其他（视频/通用/安全等）：占比 20%

区域分布
- 北美：占比 45%，成熟度最高
- 中国：占比 20%，增速全球第一（85% CAGR）
- 欧洲：占比 18%，受监管影响增速较慢
- 其他亚太地区：占比 17%

关键趋势
1. Agent 从单任务执行向多 Agent 协作演进
2. 企业更倾向采购而非自建 Agent
3. MCP 协议成为工具集成的事实标准
4. Agent 安全和合规成为企业选型的首要考量`,
  },
  {
    id: '5',
    type: 'tips',
    title: '构建生产级 Agent 的 10 个最佳实践：从 ReAct 到 Multi-Agent',
    summary: '总结了构建可靠生产级 AI Agent 的 10 个关键实践，涵盖提示词工程、工具设计、错误处理、人类监督、多 Agent 协作等核心经验。',
    source: 'LangChain Blog',
    hotScore: 87,
    publishTime: '2026-07-23T05:00:00Z',
    tags: ['最佳实践', 'LangChain', 'Agent开发', '生产级'],
    url: 'https://blog.langchain.dev/10-best-practices',
    recommendation: '这是 LangChain 官方出品的 Agent 开发实践指南，非常实用。从 ReAct 单 Agent 到多 Agent 协作，覆盖了从设计到上线的全流程，是 Agent 开发者的必读文章。',
    aiSummary: '10 个最佳实践：1) 明确 Agent 边界；2) 工具描述即文档；3) 添加人类确认步骤；4) 实现优雅降级；5) 结构化 Agent 输出；6) 用 LangGraph 管理状态；7) 添加重试与超时；8) 日志可追溯；9) 多 Agent 协作优于单 Agent；10) 持续评估与优化。',
    content: `LangChain 官方博客发布了构建生产级 Agent 的 10 个最佳实践：

1. 明确 Agent 边界
不要让 Agent 做所有事。定义清晰的输入/输出边界，将复杂任务拆分为多个专业 Agent。

2. 工具描述即文档
工具的 description 是模型选择工具的唯一依据。写得越清晰，Agent 选择越准确。

3. 添加人类确认步骤
对高风险操作（删除数据、发送邮件、支付）必须加入人类确认环节。

4. 实现优雅降级
当 LLM 调用失败或工具不可用时，Agent 应能降级到安全状态而非崩溃。

5. 结构化 Agent 输出
使用 Pydantic 模型定义输出结构，避免自由文本导致的不确定性。

6. 用 LangGraph 管理状态
复杂 Agent 需要状态管理，LangGraph 提供了声明式的状态机定义方式。

7. 添加重试与超时
LLM 调用可能超时，工具可能失败，必须有重试机制和超时设置。

8. 日志可追溯
记录每一步的输入/输出/耗时/成本，用于调试和优化。

9. 多 Agent 协作优于单 Agent
复杂任务用多个专业 Agent 协作，比单个大 Agent 更稳定可控。

10. 持续评估与优化
建立评估数据集，持续跟踪 Agent 准确率、延迟和成本。`,
  },
  {
    id: '6',
    type: 'product',
    title: 'Devin 2.0 发布：全栈自主开发 Agent 支持 50+ 步骤长链任务',
    summary: 'Cognition 发布 Devin 2.0，新版本支持更复杂的项目级任务，可自主完成从需求理解到部署上线的全流程开发，单次任务支持 50+ 步骤的连续执行。',
    source: 'Cognition Blog',
    hotScore: 85,
    publishTime: '2026-07-22T10:00:00Z',
    tags: ['Devin', '代码Agent', '自主开发', 'SWE'],
    url: 'https://devin.ai/blog/devin-2',
    recommendation: 'Devin 是首个引起广泛关注的自主代码 Agent，2.0 版本在长链任务稳定性上的突破非常关键。50+ 步骤连续执行意味着它可以处理真正复杂的项目级任务，而不再是简单的单文件修改。',
    aiSummary: 'Devin 2.0 核心升级：1) 长链任务支持 50+ 步骤；2) 新增知识库集成；3) 支持 Docker 容器隔离执行；4) 自动生成 PR + 处理 Code Review；5) 新增人类接管模式。定价 $500/月/seat。',
    content: `Cognition 发布 Devin 2.0，这是自主代码 Agent 的重大升级。

核心升级

1. 50+ 步骤长链任务
Devin 2.0 最大的突破是支持 50+ 步骤的连续任务执行。通过改进的长期记忆和上下文管理，Devin 不再在长任务中途"失忆"或重复操作。

2. 知识库集成
支持上传项目文档、API 文档、代码规范等，Devin 在执行任务时会参考知识库内容。

3. Docker 容器隔离
每个任务在独立 Docker 容器中执行，提供安全隔离和可复现的执行环境。

4. 自动 Code Review
Devin 2.0 自动创建 PR，并处理人类 Reviewer 的意见，实现真正的闭环协作。

5. 人类接管模式
当 Devin 遇到无法处理的问题时，可自动请求人类接管，人类操作后 Devin 继续执行。

定价
- Professional: $500/月/seat
- Enterprise: 定制报价，支持私有化部署`,
  },
  {
    id: '7',
    type: 'model',
    title: 'DeepSeek R2 开源：Agent 专用模型新标杆，工具调用准确率 97.2%',
    summary: 'DeepSeek 发布 R2 模型，在 Agent 工具调用和长链推理方面表现优异，完全开源支持商业使用，工具调用准确率达到 97.2%。',
    source: 'DeepSeek',
    hotScore: 93,
    publishTime: '2026-07-22T09:00:00Z',
    tags: ['DeepSeek', '开源', 'Agent模型', '工具调用'],
    url: 'https://github.com/deepseek-ai/DeepSeek-R2',
    recommendation: 'DeepSeek R2 是目前最强的开源 Agent 模型。97.2% 的工具调用准确率和 200K 上下文窗口，配合完全开源和商业可用许可，让它成为自建 Agent 系统的最佳选择之一。',
    aiSummary: 'DeepSeek R2 核心指标：1) 工具调用准确率 97.2%（开源模型最高）；2) 200K 上下文窗口；3) 支持 30+ 步骤连续推理；4) MIT 商业许可；5) 支持本地部署。在 AgentBench 上排名第三（仅次于 Claude 5 Opus 和 GPT-5）。',
    content: `DeepSeek 正式发布 R2 模型，这是目前最强的开源 Agent 专用模型。

核心指标
- 工具调用准确率：97.2%（开源模型最高，接近闭源水平）
- 上下文窗口：200K tokens
- 连续推理步骤：30+ 步（开源模型中最长）
- 许可证：MIT（完全商业可用）

AgentBench 排名
1. Claude 5 Opus: 98.5%
2. GPT-5: 97.8%
3. DeepSeek R2: 97.2% ← 开源最高
4. Qwen3-Agent: 95.8%
5. Llama 4: 94.1%

部署方式
- Hugging Face 模型下载
- vLLM / TGI 推理服务
- 支持 4-bit 量化（单 GPU 80G 可部署）
- 提供 Agent 微调脚本和示例`,
  },
  {
    id: '8',
    type: 'product',
    title: 'Coze 国际版上线：字节跳动 Agent 构建平台全面开放',
    summary: '字节跳动旗下 Agent 构建平台 Coze 正式推出国际版，支持 GPT、Claude 等主流模型接入，提供可视化 Agent 编排、插件市场和 MCP 工具集成。',
    source: 'Coze',
    hotScore: 82,
    publishTime: '2026-07-22T08:00:00Z',
    tags: ['Coze', '字节跳动', 'Agent平台', 'MCP'],
    url: 'https://www.coze.com/blog/international-launch',
    recommendation: 'Coze 是目前最完善的 Agent 构建平台之一。可视化编排 + 插件市场 + MCP 集成三大能力让它成为非技术用户构建 Agent 的首选。国际版支持多模型是关键突破。',
    aiSummary: 'Coze 国际版核心能力：1) 可视化 Agent 工作流编排；2) 支持 GPT-5/Claude 5/Gemini 3/Qwen3；3) 500+ 插件市场；4) MCP 协议原生支持；5) 一键发布到多平台（Web/Telegram/Discord/WeChat）；6) 免费额度：1000 次/天。',
    content: `字节跳动旗下 Agent 构建平台 Coze 今日正式推出国际版。

核心能力

1. 可视化工作流编排
拖拽式 Agent 工作流编辑器，支持条件分支、循环、并行执行等高级编排模式，无需编写代码。

2. 多模型支持
- OpenAI GPT-5 / GPT-4o
- Anthropic Claude 5 / Claude 4
- Google Gemini 3
- 阿里 Qwen3
- 自研模型（豆包）

3. 插件市场
500+ 预构建插件，涵盖搜索、数据库、文件处理、API 调用等常见需求。

4. MCP 协议原生支持
支持 Model Context Protocol，可接入任何 MCP 兼容的工具服务器。

5. 多平台发布
一键发布到 Web、Telegram、Discord、微信、飞书等平台。

定价
- Free: 1000 次/天
- Pro: $29/月，10000 次/天
- Enterprise: 定制报价`,
  },
  {
    id: '9',
    type: 'industry',
    title: 'Agent 创业融资盘点：2026 上半年超 20 起，代码/客服 Agent 最受资本青睐',
    summary: '2026 年上半年 Agent 赛道融资活跃，超过 20 家创业公司获得融资，代码 Agent 和客服 Agent 是资本最关注的两个方向，总融资额超 50 亿元。',
    source: '36氪',
    hotScore: 78,
    publishTime: '2026-07-22T07:00:00Z',
    tags: ['融资', '创业', '代码Agent', '客服Agent'],
    recommendation: '融资数据是观察 Agent 行业趋势的重要窗口。代码 Agent 和客服 Agent 最受资本青睐，说明这两个方向已经验证了商业模型。多 Agent 协作框架成为新的投资热点值得关注。',
    aiSummary: '2026 H1 Agent 融资核心数据：1) 总融资事件 20+ 起；2) 总融资额超 50 亿元；3) 代码 Agent 占比 35%（7 起）；4) 客服 Agent 占比 25%（5 起）；5) 多 Agent 协作框架成为新热点；6) 最大单笔：Devin 母公司 C 轮 5 亿美元。',
    content: `2026 年上半年 Agent 赛道融资盘点：

融资概况
- 总融资事件：20+ 起
- 总融资额：超 50 亿元人民币
- 平均单笔融资：2.5 亿元

按方向分布
1. 代码 Agent：7 起（35%），最受资本青睐
   - 最大单笔：Devin 母公司 Cognition C 轮 5 亿美元
   - 其他：Windsurf B 轮 8000 万美元，SWE-Agent 种子轮 3000 万

2. 客服 Agent：5 起（25%）
   - 最大单笔：Sierra AI B 轮 1.5 亿美元
   - 其他：Intercom Fin 扩展融资 5000 万

3. 多 Agent 协作框架：4 起（20%），增速最快
   - CrewAI B 轮 6000 万美元
   - AutoGen 种子轮 2500 万

4. 数据 Agent：3 起（15%）
5. 其他方向：2 起（10%）

趋势观察
1. 代码 Agent 从"辅助"到"自主"演进，投资逻辑更清晰
2. 客服 Agent 已有明确 ROI，企业付费意愿强
3. 多 Agent 协作是 2026 年最热的新方向`,
  },
  {
    id: '10',
    type: 'tips',
    title: 'MCP 协议实战：如何让你的 Agent 接入 100+ 工具',
    summary: '详细介绍如何利用 MCP（Model Context Protocol）协议快速为 Agent 接入各类工具服务器，包含实战代码示例和最佳配置方案。',
    source: 'MCP 官方文档',
    hotScore: 80,
    publishTime: '2026-07-22T06:00:00Z',
    tags: ['MCP', '工具调用', '实战教程', 'Agent工具'],
    url: 'https://modelcontextprotocol.io/tutorials/connect-100-tools',
    recommendation: 'MCP 已经成为 Agent 工具集成的事实标准。这篇教程从零开始教你如何搭建 MCP 工具生态，是 Agent 开发者的必备技能。100+ 工具接入不再是梦想。',
    aiSummary: 'MCP 实战教程要点：1) MCP Server 三步搭建；2) stdio/SSE 两种传输模式；3) 工具注册规范；4) 常用 MCP Server 清单（文件系统、数据库、搜索引擎、GitHub）；5) LangChain/Claude/自定义 Agent 集成代码示例。',
    content: `MCP (Model Context Protocol) 实战教程：

什么是 MCP？
MCP 是 Anthropic 提出的 Agent 工具调用标准协议，让 Agent 能够统一接入各类外部工具和数据源。目前已有 100+ 开源 MCP Server。

三步搭建 MCP Server

步骤 1：安装 SDK
npm install @modelcontextprotocol/sdk

步骤 2：定义工具
const server = new Server({ name: "my-tools" });
server.tool("search_web", { query: z.string() }, async ({ query }) => {
  return { results: await search(query) };
});

步骤 3：启动服务
npx @modelcontextprotocol/inspector node server.js

常用 MCP Server
- @anthropic/filesystem: 文件系统读写
- @anthropic/database: 数据库查询
- @anthropic/web-search: 网络搜索
- @anthropic/github: GitHub 操作
- @anthropic/slack: Slack 消息

Agent 集成
支持 LangChain、Claude API、OpenAI Agents SDK 等主流框架的 MCP 集成。`,
  },
  {
    id: '11',
    type: 'product',
    title: 'Manus 升级：多 Agent 协作框架支持复杂工作流定义',
    summary: 'Manus 发布重大更新，支持多个专业 Agent 协同工作，用户可以可视化定义 Agent 间的协作模式、信息传递方式和冲突解决策略。',
    source: 'Manus',
    hotScore: 76,
    publishTime: '2026-07-21T09:00:00Z',
    tags: ['Manus', '多Agent', '协作框架', '工作流'],
    url: 'https://manus.ai/blog/multi-agent-update',
    recommendation: '多 Agent 协作是 2026 年 Agent 领域最热的方向。Manus 的可视化工作流编排让非技术用户也能构建复杂的多 Agent 系统，降低了多 Agent 开发的门槛。',
    aiSummary: 'Manus 多 Agent 更新核心能力：1) 可视化工作流编排画布；2) 支持 3 种协作模式（顺序/并行/层级）；3) Agent 间消息传递机制；4) 冲突检测与解决策略；5) 共享记忆池；6) 内置 10+ 专业 Agent 模板。',
    content: `Manus 发布多 Agent 协作框架重大更新：

三种协作模式

1. 顺序模式（Sequential）
Agent A 完成 → 将结果传给 Agent B → Agent B 继续。适用于有明确依赖关系的流程。

2. 并行模式（Parallel）
多个 Agent 同时工作，最后合并结果。适用于可独立执行的子任务。

3. 层级模式（Hierarchical）
一个"管理 Agent"负责任务分配和结果整合，多个"执行 Agent"负责具体操作。适用于复杂项目。

共享机制
- 消息传递：Agent 间通过结构化消息通信
- 共享记忆池：所有 Agent 可读写共享的知识库
- 冲突解决：内置冲突检测和自动解决策略

模板市场
内置 10+ 专业 Agent 模板：
- 研究员 Agent：信息搜索与分析
- 写作 Agent：内容创作与编辑
- 审查 Agent：质量检查与合规审查
- 翻译 Agent：多语言翻译
- 数据 Agent：数据收集与可视化`,
  },
  {
    id: '12',
    type: 'product',
    title: 'Kimi Agent 正式版：月之暗面推出的中文最佳 Agent 产品',
    summary: '月之暗面发布 Kimi Agent 正式版，支持浏览器操控、文件处理和代码执行，中文理解和中文场景表现优异，是国内 Agent 产品的重要突破。',
    source: '月之暗面',
    hotScore: 79,
    publishTime: '2026-07-21T08:00:00Z',
    tags: ['Kimi', '国内Agent', '中文', '浏览器操控'],
    url: 'https://kimi.moonshot.cn/blog/kimi-agent',
    recommendation: 'Kimi Agent 是中文 Agent 场景的最佳选择。在中文理解、中文网页浏览和中文文档处理方面远超海外 Agent 产品，是国内企业部署 Agent 的重要选项。',
    aiSummary: 'Kimi Agent 核心能力：1) 浏览器操控（中文网页适配最优）；2) 文件处理（Word/PDF/Excel）；3) 代码执行（Python/JS sandbox）；4) 中文理解 benchmark 最高分；5) 免费使用 + API $0.5/M tokens。',
    content: `月之暗面正式发布 Kimi Agent：

核心能力

1. 浏览器操控
Kimi Agent 可以像人一样操作浏览器，特别针对中文网站做了适配优化。支持淘宝下单、美团点餐、12306 购票等中国特色场景。

2. 文件处理
支持 Word、PDF、Excel、PPT 等常见文档格式，可读取、编辑、转换和生成。

3. 代码执行
内置 Python 和 JavaScript 沙箱环境，支持数据分析、自动化脚本执行。

4. 中文场景优势
在中文理解、中文网页浏览、中文文档处理方面表现远超 GPT-5 和 Claude 5：
- 中文网页操作成功率：Kimi 95% vs GPT-5 82%
- 中文文档理解准确率：Kimi 96% vs Claude 5 88%

定价
- 个人用户：免费使用（每日 50 次）
- API：$0.5/M input tokens（业界最低之一）`,
  },
  {
    id: '13',
    type: 'model',
    title: 'Qwen3-Agent 发布：阿里推出专用 Agent 基座模型，中文 Agent 能力领先',
    summary: '阿里通义实验室发布 Qwen3-Agent 模型，专为 Agent 场景优化，在工具调用、复杂任务规划和中文 Agent 能力方面表现领先。',
    source: '阿里云',
    hotScore: 84,
    publishTime: '2026-07-21T07:00:00Z',
    tags: ['Qwen', '阿里', 'Agent模型', '开源'],
    url: 'https://qwenlm.github.io/blog/qwen3-agent',
    recommendation: 'Qwen3-Agent 是目前中文 Agent 场景下最强的开源模型。和 DeepSeek R2 一起构成了国产开源 Agent 模型的双雄，对于自建中文 Agent 系统的企业是首选。',
    aiSummary: 'Qwen3-Agent 核心指标：1) 中文 Agent Benchmark 最高分（98.1%）；2) 工具调用准确率 96.8%；3) 支持 Qwen-Agent 框架一站式开发；4) Apache 2.0 开源许可；5) 提供 7B/14B/72B 三个尺寸。',
    content: `阿里通义实验室发布 Qwen3-Agent 模型：

核心指标
- 中文 Agent Benchmark：98.1%（业界最高）
- 工具调用准确率：96.8%
- AgentBench 总排名：第 4
- 支持 30+ 步骤连续推理

模型尺寸
- Qwen3-Agent-7B：单 GPU 可部署，适合边缘场景
- Qwen3-Agent-14B：性价比最优，推荐大多数场景
- Qwen3-Agent-72B：性能最强，对标 Claude 5 Sonnet

配套框架
Qwen-Agent 框架提供：
- LLM 调用封装
- 工具注册与管理
- 记忆管理（短期+长期）
- 多 Agent 协作
- 一键部署脚本

许可证
Apache 2.0（完全商业可用）`,
  },
  {
    id: '14',
    type: 'industry',
    title: '欧盟 AI Agent 监管框架征求意见：要求可解释性和人类监督',
    summary: '欧盟委员会发布 AI Agent 监管框架的征求意见稿，要求所有商业 Agent 系统必须具备决策可解释性、人类监督机制和操作日志留存能力。',
    source: 'EU Commission',
    hotScore: 72,
    publishTime: '2026-07-21T06:00:00Z',
    tags: ['监管', '欧盟', '合规', '可解释性'],
    recommendation: 'Agent 监管是行业走向成熟的标志。欧盟的征求意见稿将成为全球 Agent 监管的重要参考，出海企业必须关注。可解释性和人类监督的要求会直接影响 Agent 的架构设计。',
    aiSummary: '欧盟 Agent 监管框架核心要求：1) 决策可解释性（Agent 必须能解释每一步操作的原因）；2) 人类监督机制（关键操作需人类确认）；3) 操作日志留存（至少 5 年）；4) Agent 身份标识（必须告知用户正在与 Agent 交互）；5) 安全红线（禁止 Agent 自我复制/获取 root 权限）。',
    content: `欧盟委员会发布 AI Agent 监管框架征求意见稿：

核心要求

1. 决策可解释性
所有商业 Agent 系统必须能够解释其每一步操作的原因和依据。黑箱式 Agent 将不被允许。

2. 人类监督机制
关键操作（如金融交易、医疗决策、法律操作）必须有人类确认步骤。完全自主 Agent 在高风险场景下被禁止。

3. 操作日志留存
Agent 的所有操作日志必须留存至少 5 年，确保事后可追溯和审计。

4. Agent 身份标识
Agent 必须在交互开始时告知用户正在与 AI Agent 互动，不得伪装为人类。

5. 安全红线
- 禁止 Agent 自我复制
- 禁止 Agent 获取系统 root 权限
- 禁止 Agent 未经授权访问其他系统

影响范围
该框架预计 2027 年生效，将直接影响：
- 出海欧洲的 Agent 产品
- 使用 Agent 的企业客户
- Agent 开发框架的合规设计`,
  },
  {
    id: '15',
    type: 'tips',
    title: '从零搭建企业级客服 Agent：完整技术方案与实战代码',
    summary: '详细介绍了从零搭建企业级客服 Agent 的完整技术方案，涵盖意图识别、知识库检索、多轮对话管理和工单自动处理等核心模块。',
    source: '技术社区',
    hotScore: 75,
    publishTime: '2026-07-21T05:00:00Z',
    tags: ['客服Agent', '技术方案', 'RAG', '实战代码'],
    url: 'https://tech-community.com/build-customer-service-agent',
    recommendation: '客服 Agent 是 Agent 落地最快、ROI 最明确的方向。这篇教程从架构设计到代码实现非常完整，包含 RAG 知识库、意图路由和人工转接三大核心模块，可直接参考落地。',
    aiSummary: '客服 Agent 技术方案核心模块：1) 意图识别（分类 Agent + 置信度阈值）；2) RAG 知识库（向量检索 + 重排序）；3) 多轮对话管理（LangGraph 状态机）；4) 人工转接规则（置信度 < 0.7 自动转人工）；5) 工单自动处理（结构化输出 + API 调用）。',
    content: `从零搭建企业级客服 Agent 完整方案：

架构设计
┌─────────────┐
│  用户输入     │
└──────┬──────┘
       ↓
┌─────────────┐
│ 意图识别Agent │ → 置信度 < 0.7 → 转人工
└──────┬──────┘
       ↓
┌─────────────┐
│  路由分发     │ → 查询类/操作类/投诉类
└──────┬──────┘
       ↓
┌──────────────┐
│ RAG 知识库检索 │ → 向量检索 + BM25 + 重排序
└──────┬───────┘
       ↓
┌──────────────┐
│  回答生成Agent │ → 引用来源 + 置信度评分
└──────┬───────┘
       ↓
┌──────────────┐
│  人工审核/转接  │ → 必要时转接人工客服
└──────────────┘

核心技术
1. 意图识别：使用分类 Agent + 置信度阈值，低于 0.7 自动转人工
2. RAG 知识库：向量检索 + BM25 混合检索 + Cross-Encoder 重排序
3. 多轮对话：LangGraph 状态机管理对话状态
4. 工单处理：Pydantic 结构化输出 + 后端 API 调用
5. 人工转接：WebSocket 实时转接到人工客服系统

关键指标
- 意图识别准确率目标：> 95%
- 自动解决率目标：> 70%
- 平均响应时间目标：< 3 秒`,
  },
  {
    id: '16',
    type: 'product',
    title: 'Cursor Agent 模式升级：深度理解整个项目上下文的代码 Agent',
    summary: 'Cursor 更新 Agent 模式，现在可以理解整个项目的代码结构和上下文，自动完成跨文件的重构和功能开发，支持终端操作。',
    source: 'Cursor',
    hotScore: 88,
    publishTime: '2026-07-20T08:00:00Z',
    tags: ['Cursor', '代码Agent', 'IDE', '项目理解'],
    url: 'https://cursor.sh/blog/agent-mode-update',
    recommendation: 'Cursor 的 Agent 模式升级让它在代码 Agent IDE 赛道继续保持领先。项目级上下文理解是代码 Agent 的核心能力突破，这意味着 Cursor 不再是文件级助手，而是项目级助手。',
    aiSummary: 'Cursor Agent 模式升级核心能力：1) 项目级上下文理解（跨文件引用追踪）；2) 自动重构（跨文件符号重命名+依赖更新）；3) 终端操作（运行命令+查看输出）；4) 多模型后端（GPT-5/Claude 5/Gemini 3）；5) Agent 模式 $20/月起。',
    content: `Cursor 发布 Agent 模式重大升级：

项目级上下文理解
Cursor Agent 现在可以：
- 追踪跨文件的符号引用链
- 理解项目整体架构（前端/后端/数据库）
- 识别文件间的依赖关系
- 在修改一个文件时，自动同步更新所有关联文件

自动重构能力
- 跨文件符号重命名：重命名一个函数，自动更新所有调用处
- 依赖更新：升级一个包版本，自动修改所有 import 和 API 调用
- 模式迁移：修改数据模型后，自动更新所有使用该模型的代码

终端操作
Agent 模式现在可以直接：
- 运行 shell 命令
- 查看 linter/test 输出
- 自动修复编译错误
- 运行数据库迁移

定价
- Free: 基础补全
- Pro: $20/月，Agent 模式 500 次/月
- Business: $40/月/seat，无限 Agent 模式`,
  },
  {
    id: '17',
    type: 'product',
    title: 'Dify 2.0：开源 Agent 编排平台升级，支持企业级私有化部署',
    summary: 'Dify 发布 2.0 版本，提供更强大的可视化 Agent 编排能力，支持企业级私有化部署、多租户管理和 RAG 知识库。',
    source: 'Dify',
    hotScore: 77,
    publishTime: '2026-07-20T07:00:00Z',
    tags: ['Dify', 'Agent平台', '开源', '企业部署'],
    url: 'https://dify.ai/blog/dify-2',
    recommendation: 'Dify 是目前最成熟的开源 Agent 平台。2.0 版本的企业级部署能力和多租户管理解决了企业自建 Agent 平台的核心痛点。对于不想被 Coze 等商业平台锁定的企业，Dify 是最佳选择。',
    aiSummary: 'Dify 2.0 核心升级：1) 可视化 Agent 工作流编排 V2（支持子流程+异常处理）；2) 企业级私有化部署（K8s+Helm）；3) 多租户管理（RBAC+配额控制）；4) RAG 知识库 V2（混合检索+自动切片）；5) MCP Server 一键导入；6) MIT 开源许可。',
    content: `Dify 发布 2.0 版本，这是开源 Agent 平台的重大升级：

核心升级

1. 工作流编排 V2
- 支持子流程嵌套（工作流内调用工作流）
- 异常处理（try-catch-finally 模式）
- 条件分支与循环
- 并行执行节点

2. 企业级私有化部署
- K8s + Helm Chart 一键部署
- 支持 MySQL / PostgreSQL
- 对象存储（S3 / OSS / MinIO）
- 支持 LDAP / SSO 集成

3. 多租户管理
- RBAC 权限控制
- 租户级配额管理
- 独立工作空间
- 操作审计日志

4. RAG 知识库 V2
- 混合检索（向量 + BM25）
- 自动智能切片
- 支持 PDF/Word/Excel/网页
- 增量更新

5. MCP 集成
一键导入任何 MCP Server 作为 Agent 工具，无需开发。

许可证
MIT（完全开源免费）`,
  },
  {
    id: '18',
    type: 'model',
    title: 'Google Gemini 3 发布：原生 Agent 工作流支持 + Cloud 深度集成',
    summary: 'Google 发布 Gemini 3 系列，原生支持 Agent 工作流，内置工具调用框架，与 Google Cloud 和 Vertex AI Agent Builder 深度集成。',
    source: 'Google Blog',
    hotScore: 86,
    publishTime: '2026-07-20T06:00:00Z',
    tags: ['Google', 'Gemini', 'Agent', 'Vertex AI'],
    url: 'https://blog.google/technology/ai/gemini-3',
    recommendation: 'Gemini 3 最大的差异化是原生 Agent 支持和 Google Cloud 生态集成。对于已在使用 GCP 的企业来说，Gemini 3 + Vertex AI Agent Builder 是最低摩擦的 Agent 部署路径。',
    aiSummary: 'Gemini 3 Agent 核心能力：1) 原生工具调用框架（无需 prompt engineering）；2) Vertex AI Agent Builder 集成；3) 100+ Google Cloud 内置工具；4) Gemini 3 Ultra/Pro/Flash 三档；5) 多模态 Agent（文字+图片+视频+代码）。',
    content: `Google 发布 Gemini 3 系列，原生支持 Agent 工作流：

三档模型
- Gemini 3 Ultra：最强推理，Agent 复杂任务
- Gemini 3 Pro：平衡性能与成本，大多数 Agent 场景
- Gemini 3 Flash：最快速度，简单 Agent 任务

原生 Agent 能力
1. 内置工具调用框架
无需编写复杂的提示词，Gemini 3 原生支持 function calling，支持并行工具调用。

2. 100+ Cloud 内置工具
直接调用 Google Cloud 服务：
- Cloud Storage 文件操作
- BigQuery 数据查询
- Cloud SQL 数据库操作
- Gmail / Calendar / Drive 办公工具
- Maps / Search 信息检索

3. Vertex AI Agent Builder
可视化 Agent 构建工具，拖拽式编排 Agent 工作流，一键部署到 Google Cloud。

4. 多模态 Agent
支持文字+图片+视频+代码的多模态输入输出，可处理更复杂的 Agent 场景。

定价
- Flash: $0.1/M input tokens
- Pro: $1.25/M input tokens
- Ultra: $5/M input tokens`,
  },
  {
    id: '19',
    type: 'industry',
    title: 'Agent 正在重塑 SaaS：传统软件公司的应对之策',
    summary: '随着 Agent 能力增强，传统 SaaS 软件面临被 Agent 替代的风险。a16z 分析了 Agent 对 SaaS 行业的冲击路径和传统软件公司的应对策略。',
    source: 'a16z',
    hotScore: 81,
    publishTime: '2026-07-20T05:00:00Z',
    tags: ['SaaS', '行业变革', 'a16z', 'Agent替代'],
    url: 'https://a16z.com/agent-reshaping-saas',
    recommendation: 'a16z 的这篇分析是理解 Agent 产业影响的关键文章。Agent 不仅是工具升级，而是正在重塑整个软件行业的商业模式。SaaS → Agent-as-a-Service 的转变将影响所有软件公司。',
    aiSummary: 'a16z 核心观点：1) Agent 将替代 30% 的 SaaS 功能（搜索/筛选/报告）；2) SaaS 定价模式从按席位转向按任务量；3) Agent-Native SaaS（如 Sierra AI）正在颠覆传统客服 SaaS；4) 传统 SaaS 的护城河是数据和流程，不是 UI；5) "Agent 优先"策略是传统 SaaS 的最佳应对。',
    content: `a16z 发布 Agent 对 SaaS 行业影响分析报告：

Agent 替代路径
1. 第一波：自动化操作（搜索/筛选/整理）→ 替代数据分析师
2. 第二波：自动化决策（推荐/审核/执行）→ 替代中层管理
3. 第三波：自动化创作（生成/编辑/优化）→ 替代内容工作者

SaaS → Agent-as-a-Service
- 传统 SaaS：按席位收费，用户自己操作软件
- Agent SaaS：按任务收费，Agent 替代用户操作
- 影响：30% 的 SaaS 功能将被 Agent 替代

案例
1. Sierra AI（客服 Agent）→ 替代 Zendesk
2. Harvey（法律 Agent）→ 替代法律 SaaS
3. Cursor（代码 Agent）→ 替代传统 IDE

传统 SaaS 应对策略
1. Agent 优先策略：先设计 Agent，再设计 UI
2. 开放 API：让 Agent 能调用你的服务
3. 数据护城河：积累独有数据，Agent 离不开你
4. 按任务定价：拥抱新的定价模式`,
  },
  {
    id: '20',
    type: 'tips',
    title: 'Agent 提示词工程终极指南：让 LLM 稳定执行复杂任务',
    summary: '系统总结了 Agent 场景下的提示词工程方法论，包括系统提示词设计、工具描述优化、Few-shot 策略和防幻觉技巧。',
    source: 'Anthropic Blog',
    hotScore: 83,
    publishTime: '2026-07-19T05:00:00Z',
    tags: ['Prompt', 'Agent', '提示词工程', '方法论'],
    url: 'https://docs.anthropic.com/prompt-engineering-for-agents',
    recommendation: '提示词工程是 Agent 稳定性的基础。Anthropic 这篇指南是目前最系统、最实用的 Agent 提示词方法论，覆盖了从系统提示词到工具描述到防幻觉的全套技巧。',
    aiSummary: 'Agent 提示工程核心技巧：1) 系统提示词=角色+能力+约束+示例；2) 工具描述需包含用途/参数/返回值/错误处理；3) Few-shot 比零样本稳定 40%；4) Chain-of-thought + 自检提升准确率 25%；5) 结构化输出约束减少幻觉 60%。',
    content: `Anthropic 发布 Agent 提示词工程终极指南：

1. 系统提示词四要素
- 角色：你是一个专业的XX Agent
- 能力：你可以使用以下工具...
- 约束：你必须遵守以下规则...
- 示例：遇到XX情况时，你应该...

2. 工具描述优化
每个工具描述需包含：
- 用途说明：这个工具做什么
- 参数说明：每个参数的类型和含义
- 返回值：返回什么格式的数据
- 错误处理：失败时怎么处理
- 使用时机：什么情况下应该调用

3. Few-shot 策略
提供 2-3 个完整的 Agent 执行示例，比零样本提示稳定 40%：
- 展示思考过程（Chain-of-Thought）
- 展示工具选择逻辑
- 展示错误处理方式

4. 防幻觉技巧
- 结构化输出约束（用 JSON Schema 约束输出格式）
- 自检机制（Agent 生成后自检结果）
- 引用来源（要求标注信息出处）
- 置信度评估（对不确定的结果标注置信度）`,
  },
];
