import { NextRequest, NextResponse } from 'next/server';
import Parser from 'rss-parser';
import {
  SOURCES,
  calculateHotScore,
  isAgentRelated,
  autoClassify,
  type SourceConfig,
} from '@/data/rss-sources';
import { fetchAnthropicNews } from '@/lib/fetchers/anthropic';
import { fetchHackerNews } from '@/lib/fetchers/hackernews';
import { fetchAihot } from '@/lib/fetchers/aihot';
import { fetchMcpAibase } from '@/lib/fetchers/mcpaibase';
import type { FeedItem } from '@/data/types';

const parser = new Parser({
  timeout: 15_000,
  headers: {
    'User-Agent':
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
    Accept:
      'application/rss+xml, application/xml, text/xml, application/atom+xml',
  },
});

// Cache for 10 minutes
let cachedFeed: FeedItem[] | null = null;
let cacheTimestamp: number = 0;
const CACHE_DURATION = 10 * 60 * 1000;

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type') || 'all';
  const search = searchParams.get('q') || '';
  const limit = parseInt(searchParams.get('limit') || '100');
  const offset = parseInt(searchParams.get('offset') || '0');
  const sourceFilter = searchParams.get('source'); // single source id
  const forceRefresh = searchParams.get('refresh') === 'true';

  // Return cached if fresh
  if (!forceRefresh && cachedFeed && Date.now() - cacheTimestamp < CACHE_DURATION) {
    return NextResponse.json({
      items: filterAndPaginate(cachedFeed, type, search, sourceFilter, limit, offset),
      total: cachedFeed.length,
      cached: true,
      lastUpdated: new Date(cacheTimestamp).toISOString(),
    });
  }

  const now = new Date();

  // Fetch all sources in parallel (each fetcher handles its own failures)
  const settled = await Promise.allSettled(
    SOURCES.map((s) => fetchSource(s, now))
  );

  const allItems: FeedItem[] = [];
  const stats: Record<string, { ok: boolean; count: number }> = {};

  settled.forEach((res, i) => {
    const source = SOURCES[i];
    if (res.status === 'fulfilled') {
      stats[source.id] = { ok: true, count: res.value.length };
      allItems.push(...res.value);
    } else {
      stats[source.id] = { ok: false, count: 0 };
      console.warn(`[${source.id}]`, res.reason);
    }
  });

  // Dedupe by url (some HN items may share urls, also safety net)
  const deduped = dedupeByUrl(allItems);

  // Sort by hot score then by date
  deduped.sort((a, b) => {
    if (b.hotScore !== a.hotScore) return b.hotScore - a.hotScore;
    return new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime();
  });

  cachedFeed = deduped;
  cacheTimestamp = Date.now();

  return NextResponse.json({
    items: filterAndPaginate(deduped, type, search, sourceFilter, limit, offset),
    total: deduped.length,
    cached: false,
    lastUpdated: new Date().toISOString(),
    sources: stats,
  });
}

async function fetchSource(source: SourceConfig, now: Date): Promise<FeedItem[]> {
  switch (source.fetcher) {
    case 'rss':
      return fetchRss(source, now);
    case 'html':
      if (source.id === 'mcpaibase') return fetchMcpAibase(source);
      return fetchAnthropicNews(source);
    case 'api':
      if (source.id === 'aihot') return fetchAihot(source);
      return fetchHackerNews(source);
  }
}

async function fetchRss(source: SourceConfig, now: Date): Promise<FeedItem[]> {
  try {
    const feed = await parser.parseURL(source.url);
    const items = feed.items || [];
    // Only keep the 30 most recent items per RSS source.
    // We rely on rss-parser setting `isoDate` so we can sort reliably.
    const sorted = items
      .filter((it) => it.title)
      .slice()
      .sort((a, b) => {
        const ta = new Date(a.isoDate || a.pubDate || 0).getTime();
        const tb = new Date(b.isoDate || b.pubDate || 0).getTime();
        return tb - ta;
      })
      .slice(0, 30);
    return sorted
      .map((item, idx) => normalizeRssItem(item, source, idx, now))
      .filter((item): item is FeedItem => item !== null);
  } catch (err) {
    console.warn(`[rss:${source.id}]`, err instanceof Error ? err.message : err);
    return [];
  }
}

function normalizeRssItem(
  item: Record<string, unknown> & {
    title?: string;
    contentSnippet?: string;
    content?: string;
    pubDate?: string;
    isoDate?: string;
    link?: string;
  },
  source: SourceConfig,
  idx: number,
  now: Date
): FeedItem | null {
  const title = item.title || '';
  if (!title) return null;

  const rawSummary =
    (item.contentSnippet as string | undefined) ||
    (item.content as string | undefined) ||
    '';
  const summary = stripHtml(rawSummary).slice(0, 500);
  const pubDate =
    (item.isoDate as string | undefined) ||
    (item.pubDate as string | undefined) ||
    new Date().toISOString();

  const { isRelated, matchCount } = isAgentRelated(title, summary, source.agentKeywords);
  const itemType = autoClassify(title, summary, source.category);
  const hotScore = calculateHotScore({
    sourceWeight: source.weight,
    publishedDate: new Date(pubDate),
    now,
    hasAgentKeywords: isRelated,
    keywordMatchCount: matchCount,
  });
  const tags = extractTags(title, summary, source.agentKeywords);

  const url = (item.link as string | undefined) || undefined;
  const id = `${source.id}-${hashString(url || title)}-${idx}`;

  const content = stripHtml((item.content as string | undefined) || summary).slice(0, 5000);

  return {
    id,
    type: itemType,
    title,
    summary,
    source: source.name,
    hotScore,
    publishTime: pubDate,
    tags,
    url,
    recommendation: isRelated
      ? `本文来自 ${source.name}，与 Agent 领域相关（匹配关键词：${matchedKeywordList(tags, source.agentKeywords)}）。热度评分 ${hotScore}/100。`
      : `本文来自 ${source.name}，属于 ${itemType} 类动态。`,
    aiSummary: summary || '暂无 AI 摘要，请阅读原文获取完整信息。',
    content: content || summary || '暂无正文内容，请访问原文链接阅读完整文章。',
  };
}

function filterAndPaginate(
  items: FeedItem[],
  type: string,
  search: string,
  sourceFilter: string | null,
  limit: number,
  offset: number
): FeedItem[] {
  let filtered = items;

  if (type !== 'all') {
    filtered = filtered.filter((item) => item.type === type);
  }

  if (sourceFilter) {
    filtered = filtered.filter((item) => {
      // Match either by source.id (we attach a `sourceId` field via convention)
      // or by source name. Since FeedItem doesn't have sourceId, we add it
      // through a side-channel: we read tags which include the source logo prefix.
      // Simpler: skip sourceFilter for now (we map by name in client).
      return item.source.toLowerCase() === sourceFilter.toLowerCase();
    });
  }

  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.summary.toLowerCase().includes(q) ||
        item.tags.some((t) => t.toLowerCase().includes(q))
    );
  }

  return filtered.slice(offset, offset + limit);
}

function extractTags(title: string, summary: string, keywords: string[]): string[] {
  const text = `${title} ${summary}`.toLowerCase();
  const matched = keywords.filter((kw) => text.includes(kw.toLowerCase()));
  return [...new Set(matched)].slice(0, 5);
}

function matchedKeywordList(tags: string[], keywords: string[]): string {
  const matched = tags.filter((t) =>
    keywords.some((k) => k.toLowerCase() === t.toLowerCase())
  );
  return matched.length > 0 ? matched.join('、') : '通用';
}

function stripHtml(html: string): string {
  return html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function hashString(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h * 31 + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h).toString(36);
}

function dedupeByUrl(items: FeedItem[]): FeedItem[] {
  const seen = new Map<string, FeedItem>();
  for (const item of items) {
    const key = item.url || item.id;
    const existing = seen.get(key);
    if (!existing) {
      seen.set(key, item);
      continue;
    }
    // Keep the one with higher hot score
    if (item.hotScore > existing.hotScore) {
      seen.set(key, item);
    }
  }
  return Array.from(seen.values());
}