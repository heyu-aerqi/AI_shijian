import type { SourceConfig } from '@/data/rss-sources';
import type { FeedItem } from '@/data/types';

/**
 * Anthropic HTML scraper — fetches https://www.anthropic.com/news and
 * extracts article entries from the page.
 *
 * Anthropic does not provide an official RSS feed, so we scrape the HTML.
 * This is FRAGILE: if Anthropic changes their page structure, this breaks.
 *
 * Strategy:
 *  1. Fetch the news page HTML
 *  2. Look for <a href="/news/[slug]"> elements (each is a card linking to an article)
 *  3. Within each card, extract title + date
 *  4. Convert to FeedItem shape
 */
export async function fetchAnthropicNews(source: SourceConfig): Promise<FeedItem[]> {
  try {
    const res = await fetch(source.url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml',
      },
      // 15s timeout via AbortSignal
      signal: AbortSignal.timeout(15_000),
    });

    if (!res.ok) {
      console.warn(`[anthropic] HTTP ${res.status}`);
      return [];
    }

    const html = await res.text();
    return parseAnthropicHtml(html, source);
  } catch (err) {
    console.warn(`[anthropic] fetch failed:`, err instanceof Error ? err.message : err);
    return [];
  }
}

/**
 * Parse Anthropic news HTML into FeedItems.
 *
 * Anthropic's news page typically has a structure like:
 *   <a href="/news/claude-sonnet-4-5" class="...card-class...">
 *     <div>...title text...</div>
 *     <time datetime="2025-09-29">September 29, 2025</time>
 *   </a>
 *
 * We extract: /news/[slug] hrefs, plus the closest preceding title text and date.
 */
function parseAnthropicHtml(html: string, source: SourceConfig): FeedItem[] {
  const items: FeedItem[] = [];
  const seen = new Set<string>();

  // Match all anchors pointing to /news/...
  // We grab href and the entire anchor text for title/date parsing.
  const anchorRegex = /<a\s+[^>]*href="(\/news\/[a-z0-9-]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let match: RegExpExecArray | null;

  while ((match = anchorRegex.exec(html)) !== null) {
    const href = match[1];
    const innerHtml = match[2];
    if (seen.has(href)) continue;
    seen.add(href);

    // Extract title — strip all tags from inner HTML
    const text = innerHtml
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();

    // Title is typically the first sentence/line before a date
    // Heuristic: split on common date words or just take first ~120 chars
    const title = text.length > 200 ? text.slice(0, 200).trim() : text;
    if (!title || title.length < 5) continue;

    // Try to find date in the anchor — <time datetime="..."> or visible date text
    let publishTime = new Date().toISOString();
    const timeMatch = innerHtml.match(/<time[^>]*datetime="([^"]+)"/i);
    if (timeMatch) {
      const parsed = new Date(timeMatch[1]);
      if (!isNaN(parsed.getTime())) publishTime = parsed.toISOString();
    } else {
      // Look for date pattern: "September 29, 2025" or "2025-09-29"
      const dateMatch =
        innerHtml.match(/([A-Z][a-z]+ \d{1,2},? \d{4})/) ||
        innerHtml.match(/(\d{4}-\d{2}-\d{2})/);
      if (dateMatch) {
        const parsed = new Date(dateMatch[1]);
        if (!isNaN(parsed.getTime())) publishTime = parsed.toISOString();
      }
    }

    const url = `https://www.anthropic.com${href}`;

    items.push({
      id: `anthropic-${href.replace(/\//g, '-')}`,
      type: 'model',
      title,
      summary: title,
      source: 'Anthropic',
      hotScore: 0, // recalculated upstream
      publishTime,
      tags: ['Anthropic', 'Claude'],
      url,
      recommendation: `来自 Anthropic 官方的最新动态。`,
      aiSummary: title,
      content: title,
    });
  }

  return items;
}