"use client";

import { useState } from "react";
import { useFeedItems } from "@/lib/hooks";
import { feedItems } from "@/data/feed-data";
import { FeedCard, DateDivider } from "@/components/feed-card";
import { LoadingSpinner, DataStatus } from "@/components/loading";
import { formatDate } from "@/lib/date";
import { Badge } from "@/components/ui/badge";
import { FeedItem } from "@/data/types";
import { Cpu, Search } from "lucide-react";

const companyFilters = [
  { value: "all", label: "全部厂商" },
  { value: "OpenAI", label: "OpenAI" },
  { value: "Anthropic", label: "Anthropic" },
  { value: "Google", label: "Google" },
  { value: "DeepSeek", label: "DeepSeek" },
  { value: "Qwen", label: "阿里" },
  { value: "Kimi", label: "月之暗面" },
];

export default function ModelsPage() {
  const [company, setCompany] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { items, cached, lastUpdated, isLoading, mutate } = useFeedItems({
    type: "model",
    search: searchQuery,
    limit: 50,
  });

  const displayItems: FeedItem[] = items.length > 0
    ? items.filter((item) => {
        if (company === "all") return true;
        return (
          item.source.includes(company) ||
          item.tags.some((t) => t.includes(company))
        );
      })
    : feedItems.filter((item) => {
        if (item.type !== "model") return false;
        if (company !== "all") {
          return (
            item.source.includes(company) ||
            item.tags.some((t) => t.includes(company))
          );
        }
        return true;
      });

  const groupedItems = (() => {
    const groups: Record<string, FeedItem[]> = {};
    displayItems
      .sort(
        (a, b) =>
          new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime()
      )
      .forEach((item) => {
        const date = formatDate(item.publishTime);
        if (!groups[date]) groups[date] = [];
        groups[date].push(item);
      });
    return groups;
  })();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Cpu className="h-5 w-5 text-blue-500" />
          <h1 className="text-xl font-bold">模型动态</h1>
          <Badge variant="secondary" className="text-xs">
            {displayItems.length} 条
          </Badge>
        </div>
        {items.length > 0 && (
          <DataStatus cached={cached} lastUpdated={lastUpdated} onRefresh={() => mutate()} isLoading={isLoading} />
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="搜索模型动态..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-9 pl-9 pr-3 text-sm rounded-lg border border-border/50 bg-muted/50 placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-blue-500/30"
          />
        </div>
        <div className="flex items-center gap-1 flex-wrap">
          {companyFilters.map((filter) => (
            <button
              key={filter.value}
              onClick={() => setCompany(filter.value)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                company === filter.value
                  ? "bg-blue-500/10 text-blue-500 border border-blue-500/20"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Loading */}
      {isLoading && items.length === 0 && <LoadingSpinner message="正在加载模型动态..." />}

      {/* Feed */}
      {!isLoading && (
        <div className="space-y-2">
          {Object.entries(groupedItems).map(([date, dateItems]) => (
            <div key={date}>
              <DateDivider date={date} />
              <div className="space-y-2">
                {dateItems.map((item) => (
                  <FeedCard key={item.id} item={item} />
                ))}
              </div>
            </div>
          ))}
          {displayItems.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-sm">暂无相关模型动态</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
