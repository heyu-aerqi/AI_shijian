"use client";

import { BlogProject, BLOG_CATEGORY_LABELS } from "@/data/types";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, GitBranch, ExternalLink, Clock } from "lucide-react";
import { formatStars, formatDistanceToNow } from "@/lib/date";
import { cn } from "@/lib/utils";

interface BlogCardProps {
  project: BlogProject;
}

const languageColors: Record<string, string> = {
  Python: "bg-yellow-500",
  TypeScript: "bg-blue-500",
  JavaScript: "bg-yellow-400",
  Rust: "bg-orange-500",
  Go: "bg-cyan-500",
  Markdown: "bg-gray-500",
};

export function BlogCard({ project }: BlogCardProps) {
  const langColor = languageColors[project.language] || "bg-gray-400";

  return (
    <a href={project.url} target="_blank" rel="noopener noreferrer">
      <Card
        className={cn(
          "group border-border/50 bg-card/50 hover:bg-accent/50 transition-all duration-300",
          "hover:shadow-lg hover:shadow-green-500/5 hover:border-green-500/20",
          "h-full"
        )}
      >
        <CardContent className="p-5">
          {/* Header */}
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-base group-hover:text-green-500 transition-colors truncate">
                {project.name}
              </h3>
              <p className="text-xs text-muted-foreground truncate">
                {project.fullName}
              </p>
            </div>
            <Badge variant="secondary" className="text-xs flex-shrink-0">
              {BLOG_CATEGORY_LABELS[project.category]}
            </Badge>
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3 leading-relaxed">
            {project.description}
          </p>

          {/* Stats */}
          <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
            <span className="flex items-center gap-1">
              <Star className="h-3.5 w-3.5 text-yellow-500" />
              <span className="font-medium text-foreground">
                {formatStars(project.stars)}
              </span>
            </span>
            <span className="flex items-center gap-1">
              <span
                className={cn(
                  "h-2.5 w-2.5 rounded-full",
                  langColor
                )}
              />
              {project.language}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {formatDistanceToNow(project.updatedAt)}
            </span>
          </div>

          {/* Topics */}
          <div className="flex items-center gap-1 flex-wrap">
            {project.topics.slice(0, 4).map((topic) => (
              <span
                key={topic}
                className="text-xs text-muted-foreground bg-muted/50 px-1.5 py-0.5 rounded"
              >
                {topic}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>
    </a>
  );
}
