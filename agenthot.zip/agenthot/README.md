# AGENTHOT — Agent 行业动态聚合

> Agent 行业动态聚合 · 每日精选与深度分析。发现国内外 AI Agent 产品，获取行业动态、开发技巧和开源项目。

AGENTHOT 是一个基于 Next.js 16 构建的 AI Agent 行业动态聚合平台，实时抓取多个 RSS / HTML / API 数据源，自动分类、评分、去重，为开发者提供一站式的 Agent 领域资讯浏览体验。

---

## ✨ 功能特性

### 6 大 Tab 页

| Tab | 说明 | 数据来源 |
|-----|------|----------|
| **全部** | 所有动态汇总，按热度排序 | 全部数据源 |
| **模型** | AI 模型发布动态（OpenAI / Google / Anthropic / Hugging Face / DeepSeek 等） | model 类源 |
| **产品** | Agent 产品发现，16 款精选产品 + AI 产品分析 | 内置产品库 |
| **行业** | 行业新闻、融资动态、政策法规 | industry 类源 |
| **技巧** | 开发教程、架构设计、MCP 工具推荐 | tips 类源 |
| **博客** | Agent 开源项目（14 个精选 GitHub 仓库，实时拉取 star 数） | GitHub API |

### 16 个数据源

| # | 数据源 | 类型 | 抓取方式 | 分类 |
|---|--------|------|----------|------|
| 1 | OpenAI | RSS | rss-parser | 模型 |
| 2 | Google AI | RSS | rss-parser | 模型 |
| 3 | Google Blog | RSS | rss-parser | 模型 |
| 4 | Hugging Face | RSS | rss-parser | 模型 |
| 5 | Anthropic | HTML | HTML 抓取 | 模型 |
| 6 | 量子位 | RSS | rss-parser | 行业 |
| 7 | 雷锋网 | RSS | rss-parser | 行业 |
| 8 | LangChain | RSS | rss-parser | 技巧 |
| 9 | Simon Willison | RSS | rss-parser | 技巧 |
| 10 | Lil'Log | RSS | rss-parser | 技巧 |
| 11 | AWS ML | RSS | rss-parser | 技巧 |
| 12 | Cloudflare | RSS | rss-parser | 技巧 |
| 13 | Hacker News | API | REST API + 关键词过滤 | 技巧 |
| 14 | MCP AIbase | HTML | HTML 抓取（60+ MCP server） | 技巧 |
| 15 | AIHOT 精选 | API | REST API | 行业 |
| 16 | GitHub 开源项目 | API | GitHub REST API | 博客 |

### 核心能力

- **实时聚合**：并行抓取 16 个数据源，10 分钟缓存，支持手动刷新
- **自动分类**：基于关键词匹配 + 源权重的自动分类算法（模型/产品/行业/技巧）
- **热度评分**：综合源权重、时效性、Agent 关键词匹配度的 0-100 评分
- **去重**：按 URL 去重，同 URL 保留高分条目
- **搜索**：全文本搜索（标题、摘要、标签）
- **详情页**：每条动态有独立详情页，包含推荐理由、AI 摘要、正文
- **深色/浅色/系统** 三种主题切换
- **响应式设计**：桌面 + 移动端适配
- **GitHub 实时数据**：博客 Tab 实时拉取 GitHub star 数、更新时间、语言
- **AI 产品分析**：产品详情页内置 AI 产品分析面板（定位、功能、架构、竞品、优劣势）

---

## 🛠 技术栈

| 技术 | 版本 | 用途 |
|------|------|------|
| Next.js | 16.2.11 | 全栈框架（App Router） |
| React | 19.2.4 | UI 库 |
| TypeScript | ^5 | 类型安全 |
| Tailwind CSS | ^4 | 样式 |
| shadcn/ui | ^4.14 | UI 组件库 |
| SWR | ^2.4.2 | 数据请求 + 缓存 |
| rss-parser | ^3.13 | RSS 解析 |
| next-themes | ^0.4.6 | 主题切换 |
| lucide-react | ^1.26 | 图标 |

---

## 📦 环境要求

- **Node.js** ≥ 20.0.0（推荐 22 LTS 或更高）
- **npm** ≥ 10.0.0（或 pnpm / yarn）
- **操作系统**：macOS / Linux / Windows 均可
- **网络**：需要能访问外部 RSS 源和 API（部分源可能需要科学上网）

---

## 🚀 快速开始

### 方式一：双击启动（推荐 ✅）

项目内置了一键启动脚本，**无需手动敲命令**，双击即可运行。

#### macOS

1. 解压 `agenthot.zip`，得到 `agenthot/` 文件夹
2. 进入文件夹，**双击 `start.command`**
   - 首次双击若弹出「无法打开」提示，请 **右键 → 打开 → 确认打开**
   - 这是因为 macOS 默认阻止来自非 App Store 的可执行文件，右键打开一次后不再提示
3. 脚本会自动：
   - 检查 Node.js 环境（未安装会提示下载链接）
   - 首次运行自动安装依赖（1-3 分钟）
   - 启动开发服务器
   - 3 秒后自动打开浏览器

#### Windows

1. 解压 `agenthot.zip`，得到 `agenthot/` 文件夹
2. 进入文件夹，**双击 `start.bat`**
3. 脚本会自动完成同上所有步骤

> 💡 如果终端窗口闪退，说明 Node.js 未安装或未配置环境变量。请先安装 [Node.js](https://nodejs.org/)（≥ 20）。

---

### 方式二：命令行启动

#### 1. 解压

```bash
unzip agenthot.zip
cd agenthot
```

#### 2. 安装依赖

```bash
npm install
```

> 如果你使用 pnpm 或 yarn：
> ```bash
> pnpm install
> # 或
> yarn install
> ```

#### 3. 启动开发服务器

```bash
npm run dev
```

打开浏览器访问 [http://localhost:3000](http://localhost:3000)

#### 4. 构建生产版本

```bash
npm run build
npm run start
```

生产服务器默认运行在 [http://localhost:3000](http://localhost:3000)

---

## 📂 项目结构

```
agenthot/
├── src/
│   ├── app/                    # Next.js App Router 页面
│   │   ├── layout.tsx          # 根布局（Header + Footer + ThemeProvider）
│   │   ├── page.tsx            # 首页（全部动态 Tab）
│   │   ├── globals.css         # 全局样式 + Tailwind + 主题变量
│   │   ├── models/
│   │   │   └── page.tsx        # 模型动态 Tab
│   │   ├── products/
│   │   │   ├── page.tsx        # Agent 产品发现 Tab
│   │   │   └── [id]/
│   │   │       └── page.tsx    # 产品详情页
│   │   ├── industry/
│   │   │   └── page.tsx        # 行业动态 Tab
│   │   ├── tips/
│   │   │   └── page.tsx        # 开发技巧 Tab
│   │   ├── blog/
│   │   │   └── page.tsx        # 开源项目 Tab（GitHub 实时数据）
│   │   ├── items/
│   │   │   └── [id]/
│   │   │       └── page.tsx    # 动态详情页
│   │   └── api/
│   │       ├── feed/
│   │       │   └── route.ts    # Feed API（RSS 聚合 + 分类 + 评分 + 去重）
│   │       └── github/
│   │           └── route.ts    # GitHub API（实时获取 repo star 数）
│   ├── components/              # React 组件
│   │   ├── header.tsx          # 顶部导航 + 搜索
│   │   ├── feed-card.tsx       # 动态卡片
│   │   ├── blog-card.tsx       # 开源项目卡片
│   │   ├── product-card.tsx    # 产品卡片 + AI 分析面板
│   │   ├── badges.tsx          # 热度/类型/分类徽章
│   │   ├── loading.tsx         # 加载动画 + 数据状态
│   │   ├── theme-provider.tsx  # 主题 Provider
│   │   ├── theme-toggle.tsx    # 主题切换按钮
│   │   └── ui/                 # shadcn/ui 基础组件
│   │       ├── badge.tsx
│   │       ├── button.tsx
│   │       ├── card.tsx
│   │       ├── dialog.tsx
│   │       ├── input.tsx
│   │       ├── scroll-area.tsx
│   │       ├── separator.tsx
│   │       ├── sheet.tsx
│   │       └── tabs.tsx
│   ├── data/                    # 静态数据
│   │   ├── types.ts            # TypeScript 类型定义
│   │   ├── rss-sources.ts      # 16 个数据源配置 + 评分/分类算法
│   │   ├── feed-data.ts        # Feed 降级数据（API 不可用时显示）
│   │   └── product-data.ts     # 16 款 Agent 产品 + 14 个开源项目数据
│   └── lib/                     # 工具库
│       ├── hooks.ts            # SWR 请求 hooks
│       ├── date.ts             # 日期格式化
│       ├── utils.ts            # cn() 类名合并
│       └── fetchers/           # 数据抓取器
│           ├── anthropic.ts    # Anthropic HTML 抓取
│           ├── hackernews.ts   # Hacker News API 抓取
│           ├── aihot.ts        # AIHOT API 抓取
│           └── mcpaibase.ts    # MCP AIbase HTML 抓取
├── public/                      # 静态资源
│   ├── file.svg
│   ├── globe.svg
│   ├── next.svg
│   ├── vercel.svg
│   └── window.svg
├── start.command                # macOS 一键启动脚本（双击运行）
├── start.bat                    # Windows 一键启动脚本（双击运行）
├── package.json
├── tsconfig.json
├── next.config.ts
├── postcss.config.mjs
├── eslint.config.mjs
├── components.json              # shadcn/ui 配置
└── README.md                    # 本文件
```

---

## 🔧 配置说明

### 数据源配置

所有数据源在 `src/data/rss-sources.ts` 中的 `SOURCES` 数组中定义：

```typescript
{
  id: 'openai',
  name: 'OpenAI',
  url: 'https://openai.com/news/rss.xml',
  category: 'model',        // model | industry | tips
  logo: '🟢',
  fetcher: 'rss',           // rss | html | api
  agentKeywords: ['agent', 'gpt', 'o3', 'chatgpt', ...],
  weight: 10,               // 0-10，越高热度加分越多
  isChinese: false,
}
```

### 添加新数据源

1. 在 `SOURCES` 数组中添加新的 `SourceConfig` 对象
2. 如果是 RSS 源，`fetcher` 设为 `'rss'`，无需写代码
3. 如果是 HTML 源，在 `src/lib/fetchers/` 下新建抓取器并在 `api/feed/route.ts` 的 `fetchSource` 中注册
4. 如果是 API 源，同上

### 热度评分算法

```
基础分 = sourceWeight × 4          (0-40)
时效加分 = 6h内 +25 | 12h内 +20 | 24h内 +15 | 48h内 +10 | 72h内 +5
Agent相关性 = 匹配关键词 +15 + 每个匹配 +3 (上限+15)
总分上限 = 100
```

### 缓存策略

- **Feed API**：10 分钟内存缓存，前端 SWR 5 分钟轮询
- **GitHub API**：30 分钟内存缓存，前端 SWR 15 分钟轮询
- 手动刷新：点击页面右上角"刷新"按钮强制更新

---

## 🌐 部署

### Vercel 部署（推荐）

1. 将代码推送到 GitHub
2. 在 [vercel.com](https://vercel.com) 导入仓库
3. 框架自动识别为 Next.js，无需额外配置
4. 点击 Deploy

### Docker 部署

```bash
# 构建镜像
docker build -t agenthot .

# 运行容器
docker run -p 3000:3000 agenthot
```

### 其他平台

支持任何 Node.js 运行环境：
```bash
npm run build && npm run start
```

---

## ❓ 常见问题

### Q: 启动后看不到数据？

A: AGENTHOT 实时从外部 RSS 源抓取数据，需要网络连接。首次加载需要几秒钟并行抓取 16 个数据源。如果网络不通，会显示内置的降级数据。

### Q: 部分数据源显示 0 条？

A: 可能原因：
- 网络不通（部分源需要科学上网）
- 数据源网站暂时不可用
- 数据源页面结构变更（HTML 抓取器可能失效）

### Q: GitHub Tab 的 star 数是实时的吗？

A: 是的。GitHub Tab 通过 GitHub REST API 实时获取仓库的 star 数、更新时间和语言。如果 API 限流，会使用内置的静态 star 数作为降级。

### Q: 如何添加新的 RSS 源？

A: 编辑 `src/data/rss-sources.ts`，在 `SOURCES` 数组中添加新条目即可，无需写任何代码。设置 `category`、`weight`、`agentKeywords` 等参数。

### Q: 如何修改主题色？

A: 编辑 `src/app/globals.css` 中的 CSS 变量。`:root` 控制浅色主题，`.dark` 控制深色主题。

---

## 📝 License

MIT License — 可自由使用、修改和分发。

---

## 🙏 致谢

- 数据来源：OpenAI、Google、Anthropic、Hugging Face、量子位、雷锋网、LangChain、Simon Willison、Lil'Log、AWS、Cloudflare、Hacker News、MCP AIbase、AIHOT
- UI 组件：[shadcn/ui](https://ui.shadcn.com/)
- 图标：[Lucide](https://lucide.dev/)
- 框架：[Next.js](https://nextjs.org/)
