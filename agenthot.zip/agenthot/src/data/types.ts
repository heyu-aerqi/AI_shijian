export interface FeedItem {
  id: string;
  type: 'model' | 'product' | 'industry' | 'tips';
  title: string;
  summary: string;
  source: string;
  hotScore: number;
  publishTime: string;
  tags: string[];
  url?: string;
  // Detail page content
  recommendation: string; // 推荐理由
  aiSummary: string; // AI 摘要
  content: string; // 正文 (markdown-like plain text)
}

export interface AgentProduct {
  id: string;
  name: string;
  logo: string;
  description: string;
  category: 'video' | 'coding' | 'customer-service' | 'marketing' | 'data' | 'general' | 'framework' | 'other';
  tags: string[];
  hotScore: number;
  website: string;
  github?: string;
  isDomestic: boolean;
  // Detail content
  fullDescription: string; // 完整介绍
  keyFeatures: string[]; // 核心功能列表
  pricing: string; // 定价信息
  foundedYear: string; // 成立时间
  company: string; // 所属公司
  analysis?: ProductAnalysis;
}

export interface ProductAnalysis {
  positioning: string;
  coreFeatures: string[];
  techArchitecture: string;
  competitors: string[];
  strengths: string[];
  weaknesses: string[];
  useCases: string[];
  overallRating: number;
  generatedAt: string;
}

export interface BlogProject {
  id: string;
  name: string;
  fullName: string;
  description: string;
  stars: number;
  language: string;
  updatedAt: string;
  url: string;
  category: 'coding' | 'video' | 'voice' | 'framework' | 'tool' | 'mcp';
  topics: string[];
  // Detail content
  readme: string; // README 摘要
  installCmd: string; // 安装命令
  quickStart: string; // 快速开始说明
}

export const CATEGORY_LABELS: Record<string, string> = {
  video: '视频 Agent',
  coding: '代码 Agent',
  'customer-service': '客服 Agent',
  marketing: '营销 Agent',
  data: '数据 Agent',
  general: '通用 Agent',
  framework: 'Agent 框架',
  other: '其他 Agent',
};

export const BLOG_CATEGORY_LABELS: Record<string, string> = {
  coding: 'Coding Agent',
  video: 'Video Agent',
  voice: 'Voice Agent',
  framework: 'Agent Framework',
  tool: 'Agent Tool',
  mcp: 'MCP Server',
};

export const TYPE_LABELS: Record<string, string> = {
  model: '模型',
  product: '产品',
  industry: '行业',
  tips: '技巧',
};
